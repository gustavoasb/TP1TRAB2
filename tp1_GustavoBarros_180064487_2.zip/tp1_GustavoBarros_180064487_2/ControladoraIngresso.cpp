#include "ControladoraDados.h"
#include "ControladoraUsuario.h"
#include "ControladoraIngresso.h"
#include "ControladoraEventos.h"
#include <iostream>
#include <list>
#include <string>
#include <vector>

bool ControladoraIngresso::compraIngresso(ControladoraDados *database, ControladoraUsuario *usercontrol){;
    int i = 1;
    cout << "-- COMPRA DE INGRESSO --" << endl;
    Ticket ti;
    TicketCode tc;
    User logado = usercontrol->getUser();
    Cpf cpfvalue = logado.getUserCpf();
    ti.setCpf(cpfvalue);
    vector<Event> events;
    cout << "Selecione um dos eventos abaixo:" << endl;
    if(database->getEventList().size() == 0){
        cout << "Nenhum evento foi encontrado" << endl;
        cout << "--------------------------" << endl;
        return false;
    }
    for(Event v: database->getEventList()){
        EventName name = v.getNameofEvent();
        cout << i << ". " << name.getEventName() << "\n";
        events.push_back(v);
        i++;
    }
    int entrada;
    cin >> entrada;
    if(entrada > i-1 || entrada < 0){
        cout << "Opção inválida." << endl;
        cout << "--------------------------" << endl;
        return false;
    }
    string code = events[entrada-1].getCodeofEvent().getEventCode();
    int k = 1;
    cout << "Escolha a apresentação: " << endl;
    vector<Presentation> presents;
    for(Presentation z : database->getPresentationList()){
        if(code == z.getMain().getCodeofEvent().getEventCode()){
            cout << k << ". " << z.getMain().getNameofEvent().getEventName() << " - " << z.getCodeofPresentation().getPresentationCode() << " - " << z.getPresentationDate().getDate()<< endl;
            cout << "Sala: " << z.getPresentationRoom().getRoom() << " - Preço: " << z.getPresentationPrice().getPrice() << " - Horário: " << z.getPresentationSchedule().getSchedule() << endl;
            cout << z.getPresentationAvailability().getAvailability() << " ingressos diponíveis" << endl;
            presents.push_back(z);
            k++; 
        }
    }
    int pr;
    cin >> pr;
    if(pr > k-1 || pr < 0){
        cout << "Opção inválida." << endl;
        cout << "--------------------------" << endl;
        return false;
    }
    bool result = database->diminuiDisponibilidade(1,presents[pr-1]);
    if(result == 0){
        return false;
    }
    string scode;
    ti.setPresentation(presents[pr-1]);
    int n_tickets = database->getNTickets();
    int tmp = n_tickets;
    int a = 0;
    if(n_tickets == 0){
        scode = "00000";
    }
    else{
        while(tmp >= 1){
            tmp/10;
            a++;
        }
    }
    string zero = "0";
    for(int j = 0; j < 4-a; j++){
        zero.append(zero);
    }
    string n_tickets_str = to_string(n_tickets);
    zero.append(n_tickets_str);
    tc.setTicketCode(scode);
    database->acrescentaTicket(1);
    ti.setCodeofTicket(tc);
    database->armazenaTicket(ti);
    database->acrescentaTicket(1);
    cout << "INGRESSO ADQUIRIDO COM SUCESSO" << endl;
    cout << "--------------------------" << endl;
    return true;
}