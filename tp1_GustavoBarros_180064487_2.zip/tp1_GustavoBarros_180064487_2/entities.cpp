#include "entities.h"
#include <string>
using namespace std;

//User
void User::setUserCpf(const Cpf &usercpf){
    this->usercpf = usercpf;
}
Cpf User::getUserCpf() const {
    return this->usercpf;
}
void User::setUserPassword(const Password &userpassword){
    this->userpassword = userpassword;
}
Password User::getUserPassword() const {
    return this->userpassword;
}
void User::acrescentaNEventos(int n){
    this->n_eventos = this->n_eventos + n;
}
int User::getNEventos(){
    return this->n_eventos;
}
//Event
void Event::setCodeofEvent(const EventCode &code){
    this->code = code;
}
EventCode Event::getCodeofEvent() const{
    return this->code;
}
void Event::setNameofEvent(const EventName &name){
    this->name = name;
}
EventName Event::getNameofEvent() const{
    return this->name;
}
void Event::setEventCity(const City &city){
    this->city = city;
}
City Event::getEventCity() const{
    return this->city;
}
void Event::setEventState(const State &state){
    this->state = state;
}
State Event::getEventState() const{
    return this->state;
}
void Event::setClassofEvent(const EventClass &eclass){
    this->eclass = eclass;
}
EventClass Event::getClassofEvent() const{
    return this->eclass;
}
void Event::setEventAgeRange(const AgeRange &agerange){
    this->agerange = agerange;
}
AgeRange Event::getEventAgeRange() const{
    return this->agerange;
}
void Event::setOwner(User x){
    this->owner = x;
}
User Event::getOwner(){
    return this->owner;
}
void Event::acrescentaNPresentations(int k){
    this->n_presentations = this->n_presentations+k;
}
int Event::getNPresentations(){
    return this->n_presentations;
}

//Presentation
void Presentation::setCodeofPresentation(const PresentationCode &code){
    this->code = code;
}
PresentationCode Presentation::getCodeofPresentation() const{
    return this->code;
}
void Presentation::setPresentationDate(const Date &date){
    this->date = date;
}
Date Presentation::getPresentationDate() const{
    return this->date;
}
void Presentation::setPresentationSchedule(const Schedule &schedule){
    this->schedule = schedule;
}
Schedule Presentation::getPresentationSchedule() const{
    return this->schedule;
}
void Presentation::setPresentationPrice(const Price &price){
    this->price = price;
}
Price Presentation::getPresentationPrice() const{
    return this->price;
}
void Presentation::setPresentationRoom(const Room &room){
    this->room = room;
}
Room Presentation::getPresentationRoom() const{
    return this->room;
}
void Presentation::setPresentationAvailability(const Availability &available){
    this->available = available;
}
Availability Presentation::getPresentationAvailability() const{
    return this->available;
}
void Presentation::setMain(Event x){
    this->main = x;
}
Event Presentation::getMain(){
    return this->main;
}

//Ticket
void Ticket::setCodeofTicket(const TicketCode &code){
    this->code = code;
}
TicketCode Ticket::getCodeofTicket() const{
    return this->code;
}
void Ticket::setPresentation(Presentation x){
    this->x = x;
}
Presentation Ticket::getPresentation(){
    return this->x;
}
void Ticket::setCpf(Cpf cpf){
    this->cpf = cpf;
}
Cpf Ticket::getCpf(){
    return this->cpf;
}

//Credit card
void CreditCard::setCCNumber(const NumberCreditCard &number){
    this->number = number;
}
NumberCreditCard CreditCard::getCCNumber() const{
    return this->number;
}
void CreditCard::setCCSecurityCode(const SecurityCode &code){
    this->code = code;
}
SecurityCode CreditCard::getCCSecurityCode() const{
    return this->code;
}
void CreditCard::setCCValidityCode(const ValidityDate &date){
    this->date = date;
}
ValidityDate CreditCard::getCCValidityCode() const{
    return this->date;
}