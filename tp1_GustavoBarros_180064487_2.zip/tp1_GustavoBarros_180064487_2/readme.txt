Aluno: Gustavo Antonio Souza de Barros
Matricula: 18/0064487

Caso o arquivo de projeto do codeblocks dentro da pasta trab2 n�o funcione, execute o seguinte comando no terminal:
g++ main.cpp tests.cpp domains.cpp entities.cpp ControladoraUsuario.cpp ControladoraDados.cpp ControladoraEventos.cpp ControladoraIngresso.cpp UI.cpp

e execute-o usando:
./a