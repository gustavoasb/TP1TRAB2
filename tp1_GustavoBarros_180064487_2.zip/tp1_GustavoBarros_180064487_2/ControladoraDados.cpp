#include <list>
#include "entities.h"
#include "ControladoraDados.h"
#include <iostream>
#include <string>
#include <stdexcept>
#include "ControladoraUsuario.h"
#include <stdio.h>
#include <fstream>
#include <vector>
using namespace std;

void ControladoraDados::armazenaUser(User x){
    this->userList.push_back(x);
    
    FILE* file = fopen("users.txt","a");
    string out;
    string cpf = (x.getUserCpf()).getCpf();
    string senha = (x.getUserPassword()).getPassword();
    out.append(cpf);
    out.append(" ");
    out.append(senha);
    if (NULL != file){
        fseek(file, 0, SEEK_END);
        long int sizef = ftell(file);
        if (0 == sizef) {
            fprintf(file, out.c_str());
        }
        else{
            string newout = "\n";
            newout.append(out);
            fprintf(file, newout.c_str());
        }
    }
    fclose(file);
}

void ControladoraDados::armazenaCC(CreditCard cc){
    this->ccList.push_back(cc);

    FILE* file2 = fopen("creditcards.txt","a");
    string out;
    string number = (cc.getCCNumber()).getNumberCreditCard();
    string validade = (cc.getCCValidityCode()).getValidityDate();
    string code = to_string((cc.getCCSecurityCode()).getSecurityCode());
    out.append(number);
    out.append(" ");
    out.append(validade);
    out.append(" ");
    out.append(code);
    if (NULL != file2){
        fseek(file2, 0, SEEK_END);
        long int sizef = ftell(file2);
        if (0 == sizef) {
            fprintf(file2, out.c_str());
        }
        else{
            string newout = "\n";
            newout.append(out);
            fprintf(file2, newout.c_str());
        }
    }
    fclose(file2);
}

void ControladoraDados::readDataFiles(){
    std::ifstream infile("users.txt");
    std::ifstream infile2("creditcards.txt");
    std::string line;
    std::string line2;
    string linelist[100];
    string linelist2[100];
    int i = 0;
    while (std::getline(infile, line)){
        if(i>99){
            cout << "Limite máximo de usuários atingido.";
        }
        linelist[i] = line;
        i++;
    }
    i = 0;
    while (std::getline(infile2, line2)){
        if(i>99){
            cout << "Limite máximo de usuários atingido.";
        }
        linelist2[i] = line2;
        i++;
    }
    int k = 0;
    for(k = 0; k < i; k++){
        User x;
        CreditCard cc;
        Cpf n;
        Password key;
        NumberCreditCard number;
        ValidityDate date;
        SecurityCode code;
        number.setNumberCreditCard(linelist2[k].substr(0,16));
        date.setValidityDate(linelist2[k].substr(17,5));
        code.setSecurityCode(stoi(linelist2[k].substr(23,3)));
        cc.setCCNumber(number);
        cc.setCCSecurityCode(code);
        cc.setCCValidityCode(date);
        n.setCpf(linelist[k].substr(0,14));
        key.setPassword(linelist[k].substr(15,22));
        x.setUserCpf(n);
        x.setUserPassword(key);
        this->userList.push_back(x);
        this->ccList.push_back(cc);
    }
}


void ControladoraDados::listaUser(){
    int n = this->userList.size();
    cout << "Número de usuários: " << n << "\n";
    for(User v: this->userList){
        Cpf cpf = v.getUserCpf();
        cout << cpf.getCpf() << "\n";
    }
}

void ControladoraDados::listaCC(){
    int n = this->ccList.size();
    for(CreditCard v: this->ccList){
        NumberCreditCard cc = v.getCCNumber();
        cout << cc.getNumberCreditCard() << "\n";
    }
}

void ControladoraDados::listaEvento(){
    int n = this->eventList.size();
    int i = 1;
    for(Event v: this->eventList){
        EventName name = v.getNameofEvent();
        cout << i << ". " << name.getEventName() << "\n";
        i++;
    }
}

list<User> ControladoraDados::getUserList(){
    return this->userList;
}

list<CreditCard> ControladoraDados::getCCList(){
    return this->ccList;
}

list<Event> ControladoraDados::getEventList(){
    return this->eventList;
}

list<Presentation> ControladoraDados::getPresentationList(){
    return this->presentationList;
}

list<Ticket> ControladoraDados::getTicketList(){
    return this->ticketList;
}

void ControladoraDados::deletaCCData(int index){
    auto list_pos = ccList.begin();
    std::advance(list_pos, index);
    this->ccList.erase(list_pos);

    std::ifstream infile("creditcards.txt");
    std::string line;
    string lines[100];
    int i = 0;
    int j = 0;
    while(std::getline(infile, line)){
        if(index != i){
            lines[j] = line; 
            j++;
        }
        i++;
    }
    std::fstream fs;
    std::ofstream ofs;
    ofs.open("creditcards.txt", std::ofstream::trunc);
    ofs.close();
    fs.open("creditcards.txt", std::fstream::app);
    for(int k = 0; k < i; k++){
           if(k != i-1){
            fs << lines[k] << "\n";
        }
        else{
            fs << lines[k];
        }
    }
    fs.close();
}

void ControladoraDados::deletaUserData(int index){
    auto list_pos = userList.begin();
    std::advance(list_pos, index);
    this->userList.erase(list_pos);

    std::ifstream infile("users.txt");
    std::string line;
    string lines[100];
    int i = 0;
    int j = 0;
    while(std::getline(infile, line)){
        if(index != i){
            lines[j] = line; 
            j++;
        }
        i++;
    }
    std::fstream fs;
    std::ofstream ofs;
    ofs.open("users.txt", std::ofstream::trunc);
    ofs.close();
    fs.open("users.txt", std::fstream::app);
    for(int k = 0; k < i; k++){
        if(k != i-1){
            fs << lines[k] << "\n";
        }
        else{
            fs << lines[k];
        }
    }
    fs.close();
}

void ControladoraDados::armazenaEvento(Event ev){
    this->eventList.push_back(ev);
}

void ControladoraDados::armazenaPresent(Presentation pr){
    this->presentationList.push_back(pr);
}

void ControladoraDados::editaDadosEvento(Event x){
    int index = 0;
    for(Event y : this->eventList){
        if(y.getCodeofEvent().getEventCode() == x.getCodeofEvent().getEventCode()){
            break;
        }
        index++;
    }
    std::list<Event>::iterator it = this->eventList.begin();
    std::advance(it, index);
    *it = x;
    int n = 0;
    for(Presentation z : this->presentationList){
        if(z.getMain().getCodeofEvent().getEventCode() == x.getCodeofEvent().getEventCode()){
            n++;
        }
    }
    int k = 0;
    int j = 0;
    vector<int> indexes(n);
    for(Presentation z : this->presentationList){
        if(z.getMain().getCodeofEvent().getEventCode() == x.getCodeofEvent().getEventCode()){
            indexes[j] = k;
            j++;
        }
        k++;
    }
    for(int l = 0; l < n; l++){
        std::list<Presentation>::iterator it = this->presentationList.begin();
        std::advance(it, indexes[l]);
        it->setMain(x);
    }
}

void ControladoraDados::deletaEvento(Event ev){
    int index = 0;
    for(Event y : this->eventList){
        if(y.getCodeofEvent().getEventCode() == ev.getCodeofEvent().getEventCode()){
            break;
        }
        index++;
    }
    std::list<Event>::iterator it = this->eventList.begin();
    std::advance(it, index);
    this->eventList.erase(it);
    int n = 0;
    for(Presentation z : this->presentationList){
        if(z.getMain().getCodeofEvent().getEventCode() == ev.getCodeofEvent().getEventCode()){
            n++;
        }
    }
    int k = 0;
    int j = 0;
    vector<int> indexes(n);
    for(Presentation z : this->presentationList){
        if(z.getMain().getCodeofEvent().getEventCode() == ev.getCodeofEvent().getEventCode()){
            indexes[j] = k;
            j++;
        }
        k++;
    }
    for(int l = 0; l < n; l++){
        std::list<Presentation>::iterator it = this->presentationList.begin();
        std::advance(it, indexes[l]);
        this->presentationList.erase(it);
    }
}

void ControladoraDados::armazenaTicket(Ticket ticket){
    this->ticketList.push_back(ticket);
}

void ControladoraDados::acrescentaTicket(int n){
    this->n_tickets = this->n_tickets+1;
}

int ControladoraDados::getNTickets(){
    return this->n_tickets;
}

bool ControladoraDados::diminuiDisponibilidade(int n, Presentation p){
    int i = 0;
    for(Presentation x : this->presentationList){
        if(x.getCodeofPresentation().getPresentationCode() == p.getCodeofPresentation().getPresentationCode()){
            break;
        }
        i++;
    }
    std::list<Presentation>::iterator it = this->presentationList.begin();
    std::advance(it, i);
    int atual;
    atual = it->getPresentationAvailability().getAvailability();
    Availability nova;
    if(atual-1 < 0){
        return false;
    }
    else{
        nova.setAvailability(atual-1);
        it->setPresentationAvailability(nova);
        return true;
    }
}