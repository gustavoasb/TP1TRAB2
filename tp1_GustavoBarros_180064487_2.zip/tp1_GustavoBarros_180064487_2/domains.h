#ifndef DOMAINS_H_INCLUDED
#define DOMAINS_H_INCLUDED

#include <string>
#include <stdexcept>
using namespace std;


/* User classes */
class Cpf{
    private:
        string cpfvalue;
        void verifyCpf(string cpfnumber) throw (invalid_argument);
    public:
        void setCpf(string cpfnumber) throw (invalid_argument);
        string getCpf();
};


class Password{
    private: 
        string passkey;
        void verifyPassword(string key) throw (invalid_argument);
    public:
        void setPassword(string key) throw (invalid_argument);
        string getPassword();
};


/* Event classes */
class EventCode{
    private:
        string code;
        void verifyEventCode(string code) throw (invalid_argument);
    public:
        void setEventCode(string code) throw (invalid_argument);
        string getEventCode();
};

class EventName{
    private:
        string name;
        void verifyEventName(string name) throw (invalid_argument);
    public:
        void setEventName(string name) throw (invalid_argument);
        string getEventName();
};

class City{
    private:
        string city;
        void verifyCity(string city) throw (invalid_argument);
    public:
        void setCity(string city) throw (invalid_argument);
        string getCity();
};

class State{
    private:
        string state;
        void verifyState(string state) throw (invalid_argument);
    public:
        void setState(string state) throw (invalid_argument);
        string getState();
};

class EventClass{
    private:
        int eclass;
        void verifyEventClass(int eclass) throw (invalid_argument);
    public:
        void setEventClass(int eclass) throw (invalid_argument);
        int getEventClass();
};

class AgeRange{
    private:
        string age;
        void verifyAge(string age) throw (invalid_argument);
    public:
        void setAge(string age) throw (invalid_argument);
        string getAge();
};


/* Presentation classes */
class PresentationCode{
    private:
        string code;
        void verifyPresentationCode(string code) throw (invalid_argument);
    public:
        void setPresentationCode(string code) throw (invalid_argument);
        string getPresentationCode();
};

class Date{
    private:
        string date;
        void verifyDate(string date) throw (invalid_argument);
    public:
        void setDate(string date) throw (invalid_argument);
        string getDate();
};

class Schedule{
    private:
        string schedule;
        void verifySchedule(string schedule) throw (invalid_argument);
    public:
        void setSchedule(string schedule) throw (invalid_argument);
        string getSchedule();
};

class Price{
    private:
        string reais;
        void verifyPrice(string reais) throw (invalid_argument);
    public:
        void setPrice(string reais) throw (invalid_argument);
        string getPrice();
};

class Room{
    private:
        int room;
        void verifyRoom(int room) throw (invalid_argument);
    public:
        void setRoom(int room) throw (invalid_argument);
        int getRoom();
};

class Availability{
    private:
        int available;
        void verifyAvailability(int available) throw (invalid_argument);
    public:
    Availability(){
        available = 250;
    }
        void setAvailability(int available) throw (invalid_argument);
        int getAvailability();
};


/* Ticket classes */
class TicketCode{
    private:
        string code;
        void verifyTicketCode(string code) throw (invalid_argument);
    public:
        void setTicketCode(string code) throw (invalid_argument);
        string getTicketCode();
};


/* Credit card classes */
class NumberCreditCard{
    private:
        string number;
        void verifyNumberCreditCard(string number) throw (invalid_argument);
    public:
        void setNumberCreditCard(string number) throw (invalid_argument);
        string getNumberCreditCard();
};

class SecurityCode{
    private:
        int scode;
        void verifySecurityCode(int number) throw (invalid_argument);
    public:
        void setSecurityCode(int number) throw (invalid_argument);
        int getSecurityCode();
};

class ValidityDate{
    private:
        string date;
        void verifyValidityDate(string date) throw (invalid_argument);
    public:
        void setValidityDate(string date) throw (invalid_argument);
        string getValidityDate();
};

#endif // DOMAINS_H_INCLUDED