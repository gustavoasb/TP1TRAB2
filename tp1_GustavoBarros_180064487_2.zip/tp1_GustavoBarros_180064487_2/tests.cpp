#include <iostream>
#include "tests.h"

void DomainTests(){
    cout << "-- Testing user domains --\n";
    TUCpf testcpf;
    switch(testcpf.run()){
        case TUCpf::SUCCESS: cout << "CPF: OK\n";
                                break;
        case TUCpf::FAILURE: cout << "Error\n";
                                break;
    }
    TUPassword testpassword;
    switch(testpassword.run()){
        case TUPassword::SUCCESS: cout << "Password: OK\n";
                                break;
        case TUPassword::FAILURE: cout << "Error\n";
                                break;
    }
    cout << "\n";
    cout << "-- Testing event domains --\n";
    TUEventCode testeventcode;
    switch(testeventcode.run()){
        case TUEventCode::SUCCESS: cout << "Event Code: OK\n";
                                break;
        case TUEventCode::FAILURE: cout << "Event Code: Error\n";
                                break;
    }
    TUEventName testeventname;
    switch(testeventname.run()){
        case TUEventName::SUCCESS: cout << "Event Name: OK\n";
                                break;
        case TUEventName::FAILURE: cout << "Event Name: Error\n";
                                break;
    }
    TUCity testcity;
    switch(testcity.run()){
        case TUCity::SUCCESS: cout << "City: OK\n";
                                break;
        case TUCity::FAILURE: cout << "City: Error\n";
                                break;
    }
    TUState teststate;
    switch(teststate.run()){
        case TUState::SUCCESS: cout << "State: OK\n";
                                break;
        case TUState::FAILURE: cout << "State: Error\n";
                                break;
    }
    TUEventClass testeventclass;
    switch(testeventclass.run()){
        case TUEventClass::SUCCESS: cout << "Event Class: OK\n";
                                break;
        case TUEventClass::FAILURE: cout << "Event Class: Error\n";
                                break;
    }
    TUAgeRange testagerange;
    switch(testagerange.run()){
        case TUAgeRange::SUCCESS: cout << "Age Range: OK\n";
                                break;
        case TUAgeRange::FAILURE: cout << "Age Range: Error\n";
                                break;
    }
    cout << "\n";
    cout << "-- Testing presentation domains --\n";
    TUPresentationCode testprcode;
    switch(testprcode.run()){
        case TUPresentationCode::SUCCESS: cout << "Presentation Code: OK\n";
                                break;
        case TUPresentationCode::FAILURE: cout << "Presentation Code: Error\n";
                                break;
    }
    TUDate testdate;
    switch(testdate.run()){
        case TUDate::SUCCESS: cout << "Date: OK\n";
                                break;
        case TUDate::FAILURE: cout << "Date: Error\n";
                                break;
    }
    TUSchedule testschedule;
    switch(testschedule.run()){
        case TUSchedule::SUCCESS: cout << "Schedule: OK\n";
                                break;
        case TUSchedule::FAILURE: cout << "Schedule: Error\n";
                                break;
    }
    TUPrice testprice;
    switch(testprice.run()){
        case TUPrice::SUCCESS: cout << "Price: OK\n";
                                break;
        case TUPrice::FAILURE: cout << "Price: Error\n";
                                break;
    }
    TURoom testroom;
    switch(testroom.run()){
        case TURoom::SUCCESS: cout << "Room Number: OK\n";
                                break;
        case TURoom::FAILURE: cout << "Room Number: Error\n";
                                break;
    }
    TUAvailable testavailable;
    switch(testavailable.run()){
        case TUAvailable::SUCCESS: cout << "Availability: OK\n";
                                break;
        case TUAvailable::FAILURE: cout << "Availability: Error\n";
                                break;
    }
    cout << "\n";
    cout << "-- Testing ticket domains --\n";
    TUTicketCode testtcode;
    switch(testtcode.run()){
        case TUTicketCode::SUCCESS: cout << "Ticket Code: OK\n";
                                break;
        case TUTicketCode::FAILURE: cout << "Ticket Code: Error\n";
                                break;
    }
     cout << "\n";
    cout << "-- Testing credit card domains --\n";
    TUSecurityCode testcardcode;
    switch(testcardcode.run()){
        case TUSecurityCode::SUCCESS: cout << "Credit Card CSC: OK\n";
                                break;
        case TUSecurityCode::FAILURE: cout << "Credit Card CSC: Error\n";
                                break;
    }
    TUCreditCardNumber testcardnumber;
    switch(testcardnumber.run()){
        case TUCreditCardNumber::SUCCESS: cout << "Credit Card Number: OK\n";
                                break;
        case TUCreditCardNumber::FAILURE: cout << "Credit Card Number: Error\n";
                                break;
    }
    TUValidityDate testvadate;
    switch(testvadate.run()){
        case TUValidityDate::SUCCESS: cout << "Validity Date: OK\n";
                                break;
        case TUValidityDate::FAILURE: cout << "Validity Date: Error\n";
                                break;
    }
    cout << "\n";
}

void EntitiesTests(){
    cout << "-- Testing entities --\n";
    TUUser testuser;
    switch(testuser.run()){
        case TUUser::SUCCESS: cout << "User: OK\n";
                                break;
        case TUUser::FAILURE: cout << "User: Error\n";
                                break;
    }

    TUEvent testevent;
    switch(testevent.run()){
        case TUEvent::SUCCESS: cout << "Event: OK\n";
                                break;
        case TUEvent::FAILURE: cout << "Event: Error\n";
                                break;
    }
    TUPresentation testpresentation;
    switch(testpresentation.run()){
        case TUPresentation::SUCCESS: cout << "Presentation: OK\n";
                                break;
        case TUPresentation::FAILURE: cout << "Presentation: Error\n";
                                break;
    }
    TUTicket testticket;
    switch(testticket.run()){
        case TUTicket::SUCCESS: cout << "Ticket: OK\n";
                                break;
        case TUTicket::FAILURE: cout << "Ticket: Error\n";
                                break;
    }
    TUCreditCard testcreditcard;
    switch(testcreditcard.run()){
        case TUCreditCard::SUCCESS: cout << "Credit Card: OK\n";
                                break;
        case TUCreditCard::FAILURE: cout << "Credit Card: Error\n";
                                break;
    }
}

/* User classes tests */
const string TUCpf::VALID_VALUE = "144.155.000-44";   
const string TUCpf::INVALID_VALUE = "55"; 
void TUCpf::setUp(){
    cpftest = new Cpf();
    state = SUCCESS;
}

void TUCpf::tearDown(){
    delete cpftest;
}

void TUCpf::testSucessScenario(){
    try{
        cpftest->setCpf(VALID_VALUE);
        if (cpftest->getCpf() != VALID_VALUE){
            state = FAILURE;
        }
    }
    catch(invalid_argument exception){
        state = FAILURE;
    }
}

void TUCpf::testFailureScenario(){
    try{
        cpftest->setCpf(INVALID_VALUE);
        state = FAILURE;
    }
    catch(invalid_argument excecao){
        return;
    }
}

int TUCpf::run(){
    setUp();
    testSucessScenario();
    testFailureScenario();
    tearDown();
    return state;
}

const string TUPassword::VALID_VALUE = "Test12";   
const string TUPassword::INVALID_VALUE = "test123"; 
void TUPassword::setUp(){
    passwordtest = new Password();
    state = SUCCESS;
}

void TUPassword::tearDown(){
    delete passwordtest;
}

void TUPassword::testSucessScenario(){
    try{
        passwordtest->setPassword(VALID_VALUE);
        if (passwordtest->getPassword() != VALID_VALUE){
            state = FAILURE;
        }
    }
    catch(invalid_argument exception){
        state = FAILURE;
    }
}

void TUPassword::testFailureScenario(){
    try{
        passwordtest->setPassword(INVALID_VALUE);
        state = FAILURE;
    }
    catch(invalid_argument excecao){
        return;
    }
}

int TUPassword::run(){
    setUp();
    testSucessScenario();
    testFailureScenario();
    tearDown();
    return state;
}


/* Event classes tests */
const string TUEventCode::VALID_VALUE = "000";   
const string TUEventCode::INVALID_VALUE = "1234"; 
void TUEventCode::setUp(){
    eventcodetest = new EventCode();
    state = SUCCESS;
}

void TUEventCode::tearDown(){
    delete eventcodetest;
}

void TUEventCode::testSucessScenario(){
    try{
        eventcodetest->setEventCode(VALID_VALUE);
        if (eventcodetest->getEventCode() != VALID_VALUE){
            state = FAILURE;
        }
    }
    catch(invalid_argument exception){
        state = FAILURE;
    }
}

void TUEventCode::testFailureScenario(){
    try{
        eventcodetest->setEventCode(INVALID_VALUE);
        state = FAILURE;
    }
    catch(invalid_argument excecao){
        return;
    }
}

int TUEventCode::run(){
    setUp();
    testSucessScenario();
    testFailureScenario();
    tearDown();
    return state;
}

const string TUEventName::VALID_VALUE = "UnB Event 2019.";   
const string TUEventName::INVALID_VALUE = "Event  wrong format"; 
void TUEventName::setUp(){
    eventnametest = new EventName();
    state = SUCCESS;
}

void TUEventName::tearDown(){
    delete eventnametest;
}

void TUEventName::testSucessScenario(){
    try{
        eventnametest->setEventName(VALID_VALUE);
        if (eventnametest->getEventName() != VALID_VALUE){
            state = FAILURE;
        }
    }
    catch(invalid_argument exception){
        state = FAILURE;
    }
}

void TUEventName::testFailureScenario(){
    try{
        eventnametest->setEventName(INVALID_VALUE);
        state = FAILURE;
    }
    catch(invalid_argument excecao){
        return;
    }
}

int TUEventName::run(){
    setUp();
    testSucessScenario();
    testFailureScenario();
    tearDown();
    return state;
}

const string TUCity::VALID_VALUE = "Brasilia.DF";   
const string TUCity::INVALID_VALUE = "Sao Paulo..SP"; 
void TUCity::setUp(){
    citytest = new City();
    state = SUCCESS;
}

void TUCity::tearDown(){
    delete citytest;
}

void TUCity::testSucessScenario(){
    try{
        citytest->setCity(VALID_VALUE);
        if (citytest->getCity() != VALID_VALUE){
            state = FAILURE;
        }
    }
    catch(invalid_argument exception){
        state = FAILURE;
    }
}

void TUCity::testFailureScenario(){
    try{
        citytest->setCity(INVALID_VALUE);
        state = FAILURE;
    }
    catch(invalid_argument excecao){
        return;
    }
}

int TUCity::run(){
    setUp();
    testSucessScenario();
    testFailureScenario();
    tearDown();
    return state;
}

const string TUState::VALID_VALUE = "AM";   
const string TUState::INVALID_VALUE = "PO"; 
void TUState::setUp(){
    statetest = new State();
    state = SUCCESS;
}

void TUState::tearDown(){
    delete statetest;
}

void TUState::testSucessScenario(){
    try{
        statetest->setState(VALID_VALUE);
        if (statetest->getState() != VALID_VALUE){
            state = FAILURE;
        }
    }
    catch(invalid_argument exception){
        state = FAILURE;
    }
}

void TUState::testFailureScenario(){
    try{
        statetest->setState(INVALID_VALUE);
        state = FAILURE;
    }
    catch(invalid_argument excecao){
        return;
    }
}

int TUState::run(){
    setUp();
    testSucessScenario();
    testFailureScenario();
    tearDown();
    return state;
}

const int TUEventClass::VALID_VALUE = 4;   
const int TUEventClass::INVALID_VALUE = 0; 
void TUEventClass::setUp(){
    eventclasstest = new EventClass();
    state = SUCCESS;
}

void TUEventClass::tearDown(){
    delete eventclasstest;
}

void TUEventClass::testSucessScenario(){
    try{
        eventclasstest->setEventClass(VALID_VALUE);
        if (eventclasstest->getEventClass() != VALID_VALUE){
            state = FAILURE;
        }
    }
    catch(invalid_argument exception){
        state = FAILURE;
    }
}

void TUEventClass::testFailureScenario(){
    try{
        eventclasstest->setEventClass(INVALID_VALUE);
        state = FAILURE;
    }
    catch(invalid_argument excecao){
        return;
    }
}

int TUEventClass::run(){
    setUp();
    testSucessScenario();
    testFailureScenario();
    tearDown();
    return state;
}

const string TUAgeRange::VALID_VALUE = "L";   
const string TUAgeRange::INVALID_VALUE = "28"; 
void TUAgeRange::setUp(){
    agerangetest = new AgeRange();
    state = SUCCESS;
}

void TUAgeRange::tearDown(){
    delete agerangetest;
}

void TUAgeRange::testSucessScenario(){
    try{
        agerangetest->setAge(VALID_VALUE);
        if (agerangetest->getAge() != VALID_VALUE){
            state = FAILURE;
        }
    }
    catch(invalid_argument exception){
        state = FAILURE;
    }
}

void TUAgeRange::testFailureScenario(){
    try{
        agerangetest->setAge(INVALID_VALUE);
        state = FAILURE;
    }
    catch(invalid_argument excecao){
        return;
    }
}

int TUAgeRange::run(){
    setUp();
    testSucessScenario();
    testFailureScenario();
    tearDown();
    return state;
}


/* Presentation Classes tests */
const string TUPresentationCode::VALID_VALUE = "4444";   
const string TUPresentationCode::INVALID_VALUE = "44444"; 
void TUPresentationCode::setUp(){
    presentationcodetest = new PresentationCode();
    state = SUCCESS;
}

void TUPresentationCode::tearDown(){
    delete presentationcodetest;
}

void TUPresentationCode::testSucessScenario(){
    try{
        presentationcodetest->setPresentationCode(VALID_VALUE);
        if (presentationcodetest->getPresentationCode() != VALID_VALUE){
            state = FAILURE;
        }
    }
    catch(invalid_argument exception){
        state = FAILURE;
    }
}

void TUPresentationCode::testFailureScenario(){
    try{
        presentationcodetest->setPresentationCode(INVALID_VALUE);
        state = FAILURE;
    }
    catch(invalid_argument excecao){
        return;
    }
}

int TUPresentationCode::run(){
    setUp();
    testSucessScenario();
    testFailureScenario();
    tearDown();
    return state;
}

const string TUDate::VALID_VALUE = "13/06/19";   
const string TUDate::INVALID_VALUE = "13/13/15"; 
void TUDate::setUp(){
    datetest = new Date();
    state = SUCCESS;
}

void TUDate::tearDown(){
    delete datetest;
}

void TUDate::testSucessScenario(){
    try{
        datetest->setDate(VALID_VALUE);
        if (datetest->getDate() != VALID_VALUE){
            state = FAILURE;
        }
    }
    catch(invalid_argument exception){
        state = FAILURE;
    }
}

void TUDate::testFailureScenario(){
    try{
        datetest->setDate(INVALID_VALUE);
        state = FAILURE;
    }
    catch(invalid_argument excecao){
        return;
    }
}

int TUDate::run(){
    setUp();
    testSucessScenario();
    testFailureScenario();
    tearDown();
    return state;
}

const string TUSchedule::VALID_VALUE = "08:45";   
const string TUSchedule::INVALID_VALUE = "08:43"; 
void TUSchedule::setUp(){
    scheduletest = new Schedule();
    state = SUCCESS;
}

void TUSchedule::tearDown(){
    delete scheduletest;
}

void TUSchedule::testSucessScenario(){
    try{
        scheduletest->setSchedule(VALID_VALUE);
        if (scheduletest->getSchedule() != VALID_VALUE){
            state = FAILURE;
        }
    }
    catch(invalid_argument exception){
        state = FAILURE;
    }
}

void TUSchedule::testFailureScenario(){
    try{
        scheduletest->setSchedule(INVALID_VALUE);
        state = FAILURE;
    }
    catch(invalid_argument excecao){
        return;
    }
}

int TUSchedule::run(){
    setUp();
    testSucessScenario();
    testFailureScenario();
    tearDown();
    return state;
}

const string TUPrice::VALID_VALUE = "R$ 1000,00";   
const string TUPrice::INVALID_VALUE = "R$ 1000,25"; 
void TUPrice::setUp(){
    pricetest = new Price();
    state = SUCCESS;
}

void TUPrice::tearDown(){
    delete pricetest;
}

void TUPrice::testSucessScenario(){
    try{
        pricetest->setPrice(VALID_VALUE);
        if (pricetest->getPrice() != VALID_VALUE){
            state = FAILURE;
        }
    }
    catch(invalid_argument exception){
        state = FAILURE;
    }
}

void TUPrice::testFailureScenario(){
    try{
        pricetest->setPrice(INVALID_VALUE);
        state = FAILURE;
    }
    catch(invalid_argument excecao){
        return;
    }
}

int TUPrice::run(){
    setUp();
    testSucessScenario();
    testFailureScenario();
    tearDown();
    return state;
}

const int TURoom::VALID_VALUE = 10;   
const int TURoom::INVALID_VALUE = 0; 
void TURoom::setUp(){
    roomtest = new Room();
    state = SUCCESS;
}

void TURoom::tearDown(){
    delete roomtest;
}

void TURoom::testSucessScenario(){
    try{
        roomtest->setRoom(VALID_VALUE);
        if (roomtest->getRoom() != VALID_VALUE){
            state = FAILURE;
        }
    }
    catch(invalid_argument exception){
        state = FAILURE;
    }
}

void TURoom::testFailureScenario(){
    try{
        roomtest->setRoom(INVALID_VALUE);
        state = FAILURE;
    }
    catch(invalid_argument excecao){
        return;
    }
}

int TURoom::run(){
    setUp();
    testSucessScenario();
    testFailureScenario();
    tearDown();
    return state;
}

const int TUAvailable::VALID_VALUE = 0;   
const int TUAvailable::INVALID_VALUE = 251; 
void TUAvailable::setUp(){
    availabletest = new Availability();
    state = SUCCESS;
}

void TUAvailable::tearDown(){
    delete availabletest;
}

void TUAvailable::testSucessScenario(){
    try{
        availabletest->setAvailability(VALID_VALUE);
        if (availabletest->getAvailability() != VALID_VALUE){
            state = FAILURE;
        }
    }
    catch(invalid_argument exception){
        state = FAILURE;
    }
}

void TUAvailable::testFailureScenario(){
    try{
        availabletest->setAvailability(INVALID_VALUE);
        state = FAILURE;
    }
    catch(invalid_argument excecao){
        return;
    }
}

int TUAvailable::run(){
    setUp();
    testSucessScenario();
    testFailureScenario();
    tearDown();
    return state;
}


/* Ticket classes test */
const string TUTicketCode::VALID_VALUE = "00001";   
const string TUTicketCode::INVALID_VALUE = "0000000"; 
void TUTicketCode::setUp(){
    ticketcodetest = new TicketCode();
    state = SUCCESS;
}

void TUTicketCode::tearDown(){
    delete ticketcodetest;
}

void TUTicketCode::testSucessScenario(){
    try{
        ticketcodetest->setTicketCode(VALID_VALUE);
        if (ticketcodetest->getTicketCode() != VALID_VALUE){
            state = FAILURE;
        }
    }
    catch(invalid_argument exception){
        state = FAILURE;
    }
}

void TUTicketCode::testFailureScenario(){
    try{
        ticketcodetest->setTicketCode(INVALID_VALUE);
        state = FAILURE;
    }
    catch(invalid_argument excecao){
        return;
    }
}

int TUTicketCode::run(){
    setUp();
    testSucessScenario();
    testFailureScenario();
    tearDown();
    return state;
}


/* Credit Card classes test */
const string TUCreditCardNumber::VALID_VALUE = "1234567890123456"; 
const string TUCreditCardNumber::INVALID_VALUE = "123456789012345"; 
void TUCreditCardNumber::setUp(){
    creditcardnumbertest = new NumberCreditCard();
    state = SUCCESS;
}

void TUCreditCardNumber::tearDown(){
    delete creditcardnumbertest;
}

void TUCreditCardNumber::testSucessScenario(){
    try{
        creditcardnumbertest->setNumberCreditCard(VALID_VALUE);
        if (creditcardnumbertest->getNumberCreditCard() != VALID_VALUE){
            state = FAILURE;
        }
    }
    catch(invalid_argument exception){
        state = FAILURE;
    }
}

void TUCreditCardNumber::testFailureScenario(){
    try{
        creditcardnumbertest->setNumberCreditCard(INVALID_VALUE);
        state = FAILURE;
    }
    catch(invalid_argument excecao){
        return;
    }
}

int TUCreditCardNumber::run(){
    setUp();
    testSucessScenario();
    testFailureScenario();
    tearDown();
    return state;
}

const int TUSecurityCode::VALID_VALUE = 455;   
const int TUSecurityCode::INVALID_VALUE = 10; 
void TUSecurityCode::setUp(){
    securitycodetest = new SecurityCode();
    state = SUCCESS;
}

void TUSecurityCode::tearDown(){
    delete securitycodetest;
}

void TUSecurityCode::testSucessScenario(){
    try{
        securitycodetest->setSecurityCode(VALID_VALUE);
        if (securitycodetest->getSecurityCode() != VALID_VALUE){
            state = FAILURE;
        }
    }
    catch(invalid_argument exception){
        state = FAILURE;
    }
}

void TUSecurityCode::testFailureScenario(){
    try{
        securitycodetest->setSecurityCode(INVALID_VALUE);
        state = FAILURE;
    }
    catch(invalid_argument excecao){
        return;
    }
}

int TUSecurityCode::run(){
    setUp();
    testSucessScenario();
    testFailureScenario();
    tearDown();
    return state;
}

const string TUValidityDate::VALID_VALUE = "12/55";   
const string TUValidityDate::INVALID_VALUE = "13/55"; 
void TUValidityDate::setUp(){
    validitydatetest = new ValidityDate();
    state = SUCCESS;
}

void TUValidityDate::tearDown(){
    delete validitydatetest;
}

void TUValidityDate::testSucessScenario(){
    try{
        validitydatetest->setValidityDate(VALID_VALUE);
        if (validitydatetest->getValidityDate() != VALID_VALUE){
            state = FAILURE;
        }
    }
    catch(invalid_argument exception){
        state = FAILURE;
    }
}

void TUValidityDate::testFailureScenario(){
    try{
        validitydatetest->setValidityDate(INVALID_VALUE);
        state = FAILURE;
    }
    catch(invalid_argument excecao){
        return;
    }
}

int TUValidityDate::run(){
    setUp();
    testSucessScenario();
    testFailureScenario();
    tearDown();
    return state;
}

//Entities
const string TUUser::VALID_VALUE = "150.000.000-15";
const string TUUser::INVALID_VALUE = "150.";
void TUUser::setUp(){
    usertest = new User();
    usertest->setUserCpf(cpfvalid);
    state = SUCCESS;
}

void TUUser::tearDown(){
    delete usertest;
}

void TUUser::testSucessScenario(){
    try{
        cpfvalid.setCpf(VALID_VALUE);
        usertest->setUserCpf(cpfvalid);
    }
    catch(invalid_argument exception){
        state = FAILURE;
    }
}

void TUUser::testFailureScenario(){
    try{
        cpfinvalid.setCpf(INVALID_VALUE);
        usertest->setUserCpf(cpfinvalid);
        state = FAILURE;
    }
    catch(invalid_argument excecao){
        return;
    }
}

int TUUser::run(){
    setUp();
    testSucessScenario();
    testFailureScenario();
    tearDown();
    return state;
}

const string TUEvent::VALID_VALUE = "Event 14 Name.";
const string TUEvent::INVALID_VALUE = "Ev.  invalid";
void TUEvent::setUp(){
    eventtest = new Event();
    eventtest->setNameofEvent(evvalid);
    state = SUCCESS;
}

void TUEvent::tearDown(){
    delete eventtest;
}

void TUEvent::testSucessScenario(){
    try{
        evvalid.setEventName(VALID_VALUE);
        eventtest->setNameofEvent(evvalid);
    }
    catch(invalid_argument exception){
        state = FAILURE;
    }
}

void TUEvent::testFailureScenario(){
    try{
        evinvalid.setEventName(INVALID_VALUE);
        eventtest->setNameofEvent(evinvalid);
        state = FAILURE;
    }
    catch(invalid_argument excecao){
        return;
    }
}

int TUEvent::run(){
    setUp();
    testSucessScenario();
    testFailureScenario();
    tearDown();
    return state;
}

const string TUPresentation::VALID_VALUE = "15:15";
const string TUPresentation::INVALID_VALUE = "15:13";
void TUPresentation::setUp(){
    presentationtest = new Presentation();
    presentationtest->setPresentationSchedule(scvalid);
    state = SUCCESS;
}

void TUPresentation::tearDown(){
    delete presentationtest;
}

void TUPresentation::testSucessScenario(){
    try{
        scvalid.setSchedule(VALID_VALUE);
        presentationtest->setPresentationSchedule(scvalid);
    }
    catch(invalid_argument exception){
        state = FAILURE;
    }
}

void TUPresentation::testFailureScenario(){
    try{
        scinvalid.setSchedule(INVALID_VALUE);
        presentationtest->setPresentationSchedule(scinvalid);
        state = FAILURE;
    }
    catch(invalid_argument excecao){
        return;
    }
}

int TUPresentation::run(){
    setUp();
    testSucessScenario();
    testFailureScenario();
    tearDown();
    return state;
}

const string TUTicket::VALID_VALUE = "00045";
const string TUTicket::INVALID_VALUE = "0000000";
void TUTicket::setUp(){
    tickettest = new Ticket();
    tickettest->setCodeofTicket(tcvalid);
    state = SUCCESS;
}

void TUTicket::tearDown(){
    delete tickettest;
}

void TUTicket::testSucessScenario(){
    try{
        tcvalid.setTicketCode(VALID_VALUE);
        tickettest->setCodeofTicket(tcvalid);
    }
    catch(invalid_argument exception){
        state = FAILURE;
    }
}

void TUTicket::testFailureScenario(){
    try{
        tcinvalid.setTicketCode(INVALID_VALUE);
        tickettest->setCodeofTicket(tcinvalid);
        state = FAILURE;
    }
    catch(invalid_argument excecao){
        return;
    }
}

int TUTicket::run(){
    setUp();
    testSucessScenario();
    testFailureScenario();
    tearDown();
    return state;
}

const string TUCreditCard::VALID_VALUE = "1500000044440000";
const string TUCreditCard::INVALID_VALUE = "15000030129";
void TUCreditCard::setUp(){
    cctest = new CreditCard();
    cctest->setCCNumber(ccvalid);
    state = SUCCESS;
}

void TUCreditCard::tearDown(){
    delete cctest;
}

void TUCreditCard::testSucessScenario(){
    try{
        ccvalid.setNumberCreditCard(VALID_VALUE);
        cctest->setCCNumber(ccvalid);
    }
    catch(invalid_argument exception){
        state = FAILURE;
    }
}

void TUCreditCard::testFailureScenario(){
    try{
        ccvalid.setNumberCreditCard(INVALID_VALUE);
        cctest->setCCNumber(ccinvalid);
        state = FAILURE;
    }
    catch(invalid_argument excecao){
        return;
    }
}

int TUCreditCard::run(){
    setUp();
    testSucessScenario();
    testFailureScenario();
    tearDown();
    return state;
}