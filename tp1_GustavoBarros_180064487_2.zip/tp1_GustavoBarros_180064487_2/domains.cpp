#include "domains.h"
#include <iostream>
#include <string>
#include <stdexcept>
#include <cctype>
using namespace std;


/* User classes functions */
void Cpf::verifyCpf(string cpfnumber) throw (invalid_argument){
    if(cpfnumber.length() != 14){
        throw invalid_argument("Argumento invalido.");
    }
    for(int i = 0; i < cpfnumber.length(); i++){
        if(i == 3 || i == 7){
            if(cpfnumber[i] != '.'){
                throw invalid_argument("Argumento invalido.");
            }
        }
        else if(i == 11){
            if(cpfnumber[i] != '-'){
                throw invalid_argument("Argumento invalido.");
            }
        }
        else{
            if(isdigit(cpfnumber[i]) == false){
                throw invalid_argument("Argumento invalido.");
            }
        }
    }
}


void Cpf::setCpf(string cpfnumber) throw (invalid_argument){
    verifyCpf(cpfnumber);
    this->cpfvalue = cpfnumber;
}

string Cpf::getCpf(){
    return this->cpfvalue;
}


void Password::verifyPassword(string key) throw (invalid_argument){
    int ascii[255] = {}; //Array of zeros
    int number = 0;
    int upper = 0;
    int lower = 0;
    if(key.length() > 6){
        throw invalid_argument("Argumento invalido.");
    }
    for(int i = 0; i < key.length(); i++){
        ascii[int(key[i])]++;
        if(isdigit(key[i])){
            number++;
        }
        if(islower(key[i])){
            lower++;
        }
        if(isupper(key[i])){
            upper++;
        }
    }
    if(upper < 1 || lower < 1 || number < 1){
        throw invalid_argument("Argumento invalido.");
    }
    for(int i = 0; i < 255; i++){
        if(ascii[i] > 1){
            throw invalid_argument("Argumento invalido.");
        }
    }
}

void Password::setPassword(string key) throw (invalid_argument){
    verifyPassword(key);
    this->passkey = key;
}

string Password::getPassword(){
    return this->passkey;
}


/* Event classes functions */
void EventCode::verifyEventCode(string code) throw (invalid_argument){
    if(code.length() != 3){
        throw invalid_argument("O código deve ter 3 digitos.");
    }
    for(int i = 0; i < code.length(); i++){
        if(isdigit(code[i]) == 0){
            throw invalid_argument("Digito não númerico encontrado.");
        }
    }
}

void EventCode::setEventCode(string code) throw (invalid_argument){
    verifyEventCode(code);
    this->code = code;
}

string EventCode::getEventCode(){
    return this->code;
}

void EventName::verifyEventName(string name) throw (invalid_argument){
    if(name.length() > 20){
        throw invalid_argument("Invalid Argument.");
    }
    int bol = 0, letters = 0;
    for(int i = 0; i < name.length(); i++){
        if(isblank(name[i])){
            bol++;
            if(bol > 1){
                throw invalid_argument("Invalid Argument.");
            }
        }
        if(isblank(name[i]) == false){
            bol = 0;
        }
        if((isalnum(name[i]) || isblank(name[i])) == false){
            throw invalid_argument("Invalid Argument.");
        }
        if(isalpha(name[i])){
            letters++;
        }
    }
    if(letters < 1){
        throw invalid_argument("Invalid Argument.");
    }
}

void EventName::setEventName(string name) throw (invalid_argument){
    verifyEventName(name);
    this->name = name;
}

string EventName::getEventName(){
    return this->name;
}

void City::verifyCity(string city) throw (invalid_argument){
    if(city.length() > 15){
        throw invalid_argument("Invalid Argument.");
    }
    int bol = 0, bol2 = 0, letters = 0;
    for(int i = 0; i < city.length(); i++){
        if(isblank(city[i])){
            bol++;
            if(bol > 1){
                throw invalid_argument("Invalid Argument.");
            }
        }
        if(isblank(city[i]) == false){
            bol = 0;
        }
        if((isalpha(city[i]) || isblank(city[i]) || (city[i] == '.')) == false){
            throw invalid_argument("Invalid Argument.");
        }
        if(bol2 > 0 && (isalpha(city[i]) == false)){
            throw invalid_argument("Invalid Argument.");
        }
        if(city[i] == '.'){
            bol2++;
        }
        if(city[i] != '.'){
            bol2 = 0;
        }
        if(isalpha(city[i])){
            letters++;
        }
    }
    if(letters < 1){
        throw invalid_argument("Invalid Argument.");
    }
}

void City::setCity(string city) throw (invalid_argument){
    verifyCity(city);
    this->city = city;
}

string City::getCity(){
    return this->city;
}

void State::verifyState(string state) throw (invalid_argument){
    if(state == "AC"){
        return;
    }
    else if(state == "AL"){
        return;
    }
    else if(state == "AP"){
        return;
    }
    else if(state == "AM"){
        return;
    }
    else if(state == "BA"){
        return;
    }
    else if(state == "CE"){
        return;
    }
    else if(state == "DF"){
        return;
    }
    else if(state == "ES"){
        return;
    }
    else if(state == "GO"){
        return;
    }
    else if(state == "MA"){
        return;
    }
    else if(state == "MT"){
        return;
    }
    else if(state == "MS"){
        return;
    }
    else if(state == "MG"){
        return;
    }
    else if(state == "PA"){
        return;
    }
    else if(state == "PB"){
        return;
    }
    else if(state == "PR"){
        return;
    }
    else if(state == "PE"){
        return;
    }
    else if(state == "PI"){
        return;
    }
    else if(state == "RJ"){
        return;
    }
    else if(state == "RN"){
        return;
    }
    else if(state == "RS"){
        return;
    }
    else if(state == "RO"){
        return;
    }
    else if(state == "RR"){
        return;
    }
    else if(state == "SC"){
        return;
    }
    else if(state == "SP"){
        return;
    }
    else if(state == "SE"){
        return;
    }
    else if(state == "TO"){
        return;
    }
    else{
        throw invalid_argument("Invalid Argument.");
    }
}

void State::setState(string state) throw (invalid_argument){
    verifyState(state);
    this->state = state;
}

string State::getState(){
    return this->state;
}

void EventClass::verifyEventClass(int eclass) throw (invalid_argument){
    if(eclass > 0 && eclass < 5){
        return;
    }
    else{
        throw invalid_argument("Invalid Argument.");
    }
}

void EventClass::setEventClass(int eclass) throw (invalid_argument){
    verifyEventClass(eclass);
    this->eclass = eclass;
}

int EventClass::getEventClass(){
    return this->eclass;
}

void AgeRange::verifyAge(string age) throw (invalid_argument){
    if(age == "L"){
        return;
    }
    else if(age == "10" || age == "12" || age == "14" || age == "16" || age == "18"){
        return;
    }
    else{
        throw invalid_argument("Invalid Argument.");
    }
}

void AgeRange::setAge(string age) throw (invalid_argument){
    verifyAge(age);
    this->age = age;
}

string AgeRange::getAge(){
    return this->age;
}


/* Presentation classes functions */
void PresentationCode::verifyPresentationCode(string code) throw (invalid_argument){
    if(code.length() != 4){
        throw invalid_argument("Número de digitos incorretos");
    }
    for(int k = 0; k < 4; k++){
        if(isdigit(code[k]) == 0){
            throw invalid_argument("Digito não numerico encontrado");
        }
    }
}

void PresentationCode::setPresentationCode(string code) throw (invalid_argument){
    verifyPresentationCode(code);
    this->code = code;
}

string PresentationCode::getPresentationCode(){
    return this->code;
}

void Date::verifyDate(string date) throw (invalid_argument){
    if(date.length() != 8){
        throw invalid_argument("Invalid Argument.");
    }
    if(((date[2] == '/') || (date[5] == '/')) == false){
        throw invalid_argument("Invalid Argument.");
    }
    int day = stoi(date.substr(0,2));
    int month = stoi(date.substr(3,2));
    int year = stoi(date.substr(6,2));
    if((month == 2) && day > 29){
        throw invalid_argument("Invalid Argument.");
    }
    if(day > 31 || day < 1){
        throw invalid_argument("Invalid Argument.");
    }
    if(month > 12 || month < 1){
        throw invalid_argument("Invalid Argument.");
    }
    if(year > 99 || year < 0){
        throw invalid_argument("Invalid Argument.");
    }
}

void Date::setDate(string date) throw (invalid_argument){
    verifyDate(date);
    this->date = date;
}

string Date::getDate(){
    return this->date;
}

void Schedule::verifySchedule(string schedule) throw (invalid_argument){
    if(schedule.length() != 5){
        throw invalid_argument("Invalid Argument.");
    }
    if(schedule[2] != ':'){
        throw invalid_argument("Invalid Argument.");
    }
    int hour = stoi(schedule.substr(0,2));
    int mins = stoi(schedule.substr(3,2));
    if(hour < 7 || hour > 22){
        throw invalid_argument("Invalid Argument.");
    }
    if((mins != 45) && (mins != 30) && (mins != 15) && (mins != 00)){
        throw invalid_argument("Invalid Argument.");
    }
}

void Schedule::setSchedule(string schedule) throw (invalid_argument){
    verifySchedule(schedule);
    this->schedule = schedule;
}

string Schedule::getSchedule(){
    return this->schedule;
}

void Price::verifyPrice(string price) throw (invalid_argument){
    if(price.substr(0,3) != "R$ "){
        throw invalid_argument("Formato incorreto de Preço.");
    }
    int comma = 0;
    for(int i = 0; i < price.length(); i++){
        if(price[i] == ','){
            price[i] = '.';
            comma++;
        }
    }
    if(comma > 1){
        throw invalid_argument("Formato incorreto de Preço.");
    }
    int limit = price.length() - 1;
    double realprice = stod(price.substr(3,limit));
    if(realprice > 1000.00 || realprice < 0.00){
        throw invalid_argument("Preço fora da faixa aceitada.");
    }
}   

void Price::setPrice(string price) throw (invalid_argument){
    verifyPrice(price);
    this->reais = price;
}

string Price::getPrice(){
    return this->reais;
}

void Room::verifyRoom(int room) throw (invalid_argument){
    if(room > 10 || room < 1){
        throw invalid_argument("Número de sala inválida.");
    }
}

void Room::setRoom(int room) throw (invalid_argument){
    verifyRoom(room);
    this->room = room;
}

int Room::getRoom(){
    return this->room;
}

void Availability::verifyAvailability(int available) throw (invalid_argument){
    if(available < 0 || available > 250){
        throw invalid_argument("Disponibilidade Inválida.");
    }
}

void Availability::setAvailability(int available) throw (invalid_argument){
    verifyAvailability(available);
    this->available = available;
}

int Availability::getAvailability(){
    return this->available;
}

/* Ticket classes functions */
void TicketCode::verifyTicketCode(string code) throw (invalid_argument){
    if(code.length() != 5){
        throw invalid_argument("Código de Ingresso Inválido.");
    }
    for(int i = 0; i < code.length(); i++){
        if(isdigit(code[i]) == 0){
            throw invalid_argument("Código de Ingresso Inválido.");
        }
    }
}

void TicketCode::setTicketCode(string code) throw (invalid_argument){
    verifyTicketCode(code);
    this->code = code;
}

string TicketCode::getTicketCode(){
    return this->code;
}


/* Credit card classes functions */
void NumberCreditCard::verifyNumberCreditCard(string number) throw (invalid_argument){
    if(number.length() != 16){
        throw invalid_argument("Número do cartão muito longo.");
    }
    for(int i = 0; i < number.length(); i++){
        if(isdigit(number[i]) == false){
            throw invalid_argument("Digito não-número encontrado.");
        }
    }
}

void NumberCreditCard::setNumberCreditCard(string number) throw (invalid_argument){
    verifyNumberCreditCard(number);
    this->number = number;
}

string NumberCreditCard::getNumberCreditCard(){
    return this->number;
}

void SecurityCode::verifySecurityCode(int code) throw (invalid_argument){
    if(code != 0000){
        if(code < 1000 && code > 99){
            return;
        }
        else{
            throw invalid_argument("Código de Segurança Inválido.");
        }
    }
}

void SecurityCode::setSecurityCode(int code) throw (invalid_argument){
    verifySecurityCode(code);
    this->scode = code;
}

int SecurityCode::getSecurityCode(){
    return this->scode;
}

void ValidityDate::verifyValidityDate(string date) throw (invalid_argument){
    if(date.length() > 5){
        throw invalid_argument("Data muito longa.");
    }
    for(int i = 0; i < date.length(); i++){
        if(i != 2){
            if(isdigit(date[i]) == false){
                throw invalid_argument("Dias não númericos.");
            }
        }
        else{
            if(date[i] != '/'){
                throw invalid_argument("Barra de separação '/' não encontrada.");
            }
        }
    }
    string strmonth = date.substr(0,2);
    string stryear = date.substr(3,2);
    int month = stoi(strmonth);
    int year = stoi(stryear);
    if(month < 1 || month > 12){
        throw invalid_argument("Mês Incorreto.");
    }
    if(year < 0 || year > 99){
        throw invalid_argument("Ano Incorreto.");
    }
}

void ValidityDate::setValidityDate(string date) throw (invalid_argument){
    verifyValidityDate(date);
    this->date = date;
}

string ValidityDate::getValidityDate(){
    return this->date;
}