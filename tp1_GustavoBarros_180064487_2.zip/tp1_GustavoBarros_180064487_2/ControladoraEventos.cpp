#include "ControladoraEventos.h"
#include "ControladoraDados.h"
#include <iostream>
#include <string>
#include <vector>
using namespace std;

bool ControladoraEvento::createEvent(ControladoraDados *database, ControladoraUsuario *usercontrol){
    Event x;
    string nome = "?";
    string cidade;
    string estado;
    string faixa;
    int classe;
    string codigo;
    int n_presentations = 0;
    if(usercontrol->getUser().getNEventos() > 5){
        cout << "Usuário chegou ao limite de eventos criados, encerrando sessão." << endl;
        cout << "--------------------------" << endl;
        return false;
    }
    cout << "-- CADASTRO DE EVENTO --" << endl;
    try{
        cout << "Insira o nome do evento: ";
        cin.ignore();
        getline(cin, nome);
        EventName name;
        name.setEventName(nome);
        x.setNameofEvent(name);
    } catch(invalid_argument excecao){
        cout << "Argumento Inválido Encontrado, Encerrando Cadastramento..." << endl;
        cout << "--------------------------" << endl;
        return false;
    }
    try{
        cout << "Cidade: ";
        getline(cin,cidade);
        City city;
        city.setCity(cidade);
        x.setEventCity(city);
    } catch(invalid_argument excecao){
        cout << "Argumento Inválido Encontrado, Encerrando Cadastramento..." << endl;
        cout << "--------------------------" << endl;
        return false;
    }
    try{
        cout << "Estado: ";
        cin >> estado;
        State state;
        state.setState(estado);
        x.setEventState(state);
    } catch(invalid_argument excecao){
        cout << "Argumento Inválido Encontrado, Encerrando Cadastramento..." << endl;
        cout << "--------------------------" << endl;
        return false;
    }
    try{
        cout << "Classe: ";
        cin >> classe;
        EventClass eclass;
        eclass.setEventClass(classe);
        x.setClassofEvent(eclass);
    } catch(invalid_argument excecao){
        cout << "Argumento Inválido Encontrado, Encerrando Cadastramento..." << endl;
        cout << "--------------------------" << endl;
        return false;
    }
    try{
        cout << "Faixa etária: ";
        cin >> faixa;
        AgeRange age;
        age.setAge(faixa);
        x.setEventAgeRange(age);
    } catch(invalid_argument excecao){
        cout << "Argumento Inválido Encontrado, Encerrando Cadastramento..." << endl;
        cout << "--------------------------" << endl;
        return false;
    }
    try{
        cout << "Código de evento: ";
        cin >> codigo;
        EventCode code;
        code.setEventCode(codigo);
        x.setCodeofEvent(code);
    } catch(invalid_argument excecao){
        cout << "Argumento Inválido Encontrado, Encerrando Cadastramento..." << endl;
        cout << "--------------------------" << endl;
        return false;
    }
    cout << "Digite o número de apresentações do evento: ";
    int npr;
    cin >> npr;
    if(npr > 10 || npr < 1){
        cout << "O número máximo de apresentações é 10, encerrando sessão..." << endl;
        cout << "--------------------------" << endl;
        return false;
    }
    cout << "Digite os códigos de cada apresentação: " << endl;
    vector<string> codespr(npr);
    for(int k = 0; k < npr; k++){
        cout << k+1 << ". ";
        cin >> codespr[k];
    }
    cout << "Digite as datas: " << endl;
    vector<string> dataspr(npr);
    for(int k = 0; k < npr; k++){
        cout << k+1 << ". ";
        cin >> dataspr[k];
    }
    cout << "Digite os horários: " << endl;
    vector<string> horariospr(npr);
    for(int k = 0; k < npr; k++){
        cout << k+1 << ". ";
        cin >> horariospr[k];
    }
    cout << "Digite os preços: " << endl;
    vector<string> precospr(npr);
    cin.ignore();
    for(int k = 0; k < npr; k++){
        cout << k+1 << ". ";
        getline(cin,precospr[k]);
    }
    cout << "Digite as salas: " << endl;
    vector<int> salaspr(npr);
    for(int k = 0; k < npr; k++){
        cout << k+1 << ". ";
        cin >> salaspr[k];
    }
    Presentation y;
    Schedule sch;
    PresentationCode codesp;
    Date dates;
    Price pre;
    Room sala;
    for(int k = 0; k < npr; k++){
        try{
            sch.setSchedule(horariospr[k]);
            codesp.setPresentationCode(codespr[k]);
            dates.setDate(dataspr[k]);
            pre.setPrice(precospr[k]);
            sala.setRoom(salaspr[k]);
        } catch(invalid_argument excecao){
            cout << "Argumento inválido encontrado, a apresentação " << k+1 << " não será cadastrada" << endl;
            cout << "--------------------------" << endl;
            continue;
        }
        x.acrescentaNPresentations(1);
        y.setPresentationSchedule(sch);
        y.setCodeofPresentation(codesp);
        y.setPresentationDate(dates);
        y.setPresentationRoom(sala);
        y.setPresentationPrice(pre);
        Availability av;
        av.setAvailability(250);
        y.setPresentationAvailability(av);
        n_presentations++;
        y.setMain(x);
        database->armazenaPresent(y);
    }
    x.setOwner(usercontrol->getUser());
    if(n_presentations > 0){
        usercontrol->getUser().acrescentaNEventos(1);
        database->armazenaEvento(x);
        cout << "Evento criado com sucesso.\n";
        cout << "--------------------------" << endl;
        return true;
    }
    else{
        cout << "Nenhuma apresentaçÃo foi validada, o evento não será criado." << endl;
        cout << "--------------------------" << endl;
        return false;
    }
}

bool ControladoraEvento::editEvent(ControladoraDados* database, ControladoraUsuario* usercontrol){
    list <Event> list_events = database->getEventList();
    vector<Event> my_events;
    cout << "-- EDIÇÃO DE EVENTO --" << endl;
    int i = 1;
    for(Event x : list_events){
        User dono = x.getOwner();
        Cpf cpf_dono = dono.getUserCpf();
        User logado = usercontrol->getUser();
        Cpf cpf_logado = logado.getUserCpf();
        if(cpf_dono.getCpf() == cpf_logado.getCpf()){
            EventName ev = x.getNameofEvent();
            string nome = ev.getEventName();
            cout << '(' <<  i << ')' << ' ' << nome << endl;
            i++;
            my_events.push_back(x);
        }
    }
    if(i == 1){
        cout << "Nenhum evento encontrado." << endl;
        cout << "--------------------------" << endl;
        return false;
    }
    cout << "Selecione o evento que você deseja editar: ";
    int input;
    cin >> input;
    if((input > i-1) || (input < 1)){
        cout << "Opção inválida." << endl;
        cout << "--------------------------" << endl;
        return false;
    }
    int entrada;
    Event evento = my_events[input-1];
    string alterar;
    EventName name;
    EventClass eclass;
    City city;
    State state;
    AgeRange age;
    int stop = 1;
    while(stop){
        cout << "Selecione o dado que você quer alterar:" << endl;
        cout << "(1) Nome" << endl;
        cout << "(2) Classe" << endl;
        cout << "(3) Faixa" << endl;
        cout << "(4) Cidade" << endl;
        cout << "(5) Estado" << endl;
        cout << "(6) Finalizar e salvar edição" << endl;
        cin >> entrada;
        cin.ignore();
        switch(entrada){
            case 1: cout << "Insira o dado novo: ";
                getline(cin,alterar);
                try{
                    name.setEventName(alterar);
                    evento.setNameofEvent(name);
                } catch(invalid_argument excecao){
                    cout << "Argumento inválido.";
                    break;
                }
                break;
            case 2: cout << "Insira o dado novo: ";
                cin >> alterar;
                try{
                    eclass.setEventClass(stoi(alterar));
                    evento.setClassofEvent(eclass);
                } catch(invalid_argument excecao){
                    cout << "Argumento inválido.";
                    break;
                }
                break;
            case 3: cout << "Insira o dado novo: ";
                cin >> alterar;
                try{
                    age.setAge(alterar);
                    evento.setEventAgeRange(age);
                } catch(invalid_argument excecao){
                    cout << "Argumento inválido.";
                    break;
                }
                break;
            case 4: cout << "Insira o dado novo: ";
                getline(cin,alterar);
                try{
                    city.setCity(alterar);
                    evento.setEventCity(city);
                } catch(invalid_argument excecao){
                    cout << "Argumento inválido.";
                    break;
                }
                break;
            case 5: cout << "Insira o dado novo: ";
                cin >> alterar;
                try{
                    state.setState(alterar);
                    evento.setEventState(state);
                } catch(invalid_argument excecao){
                    cout << "Argumento inválido.";
                    break;
                }
                break;
            case 6: cout << "Finalizando..." << endl;
                    stop = 0;
                    break;
            default: cout << "Opção inválida" << endl;
                    break;
        }
    }
    cout << "--------------------------" << endl;
    database->editaDadosEvento(evento);
    return true;
}

void ControladoraEvento::consultaEvent(ControladoraDados* database, ControladoraUsuario* usercontrol){
    list <Event> list_events = database->getEventList();
    cout << "-- CONSULTOR DE EVENTO --" << endl;
    int i = 1;
    for(Event x : list_events){
        User dono = x.getOwner();
        Cpf cpf_dono = dono.getUserCpf();
        User logado = usercontrol->getUser();
        Cpf cpf_logado = logado.getUserCpf();
        if(cpf_dono.getCpf() == cpf_logado.getCpf()){
            EventName ev = x.getNameofEvent();
            string nome = ev.getEventName();
            int vendidos = 0;
            int disponiveis;
            int vendas;
            for(Presentation k : database->getPresentationList()){
                if(k.getMain().getCodeofEvent().getEventCode() == x.getCodeofEvent().getEventCode()){
                    disponiveis = k.getPresentationAvailability().getAvailability();
                    vendas = 250 - disponiveis;
                    vendidos = vendas + vendidos;
                }
            }
            cout << '(' <<  i << ')' << ' ' << nome << ": " << vendidos << " ingressos vendidos." << endl;
            i++;
        }
    }
    if(i == 1){
        cout << "Você não criou nenhum evento." << endl;
    }
    cout << "--------------------------" << endl;
}

bool ControladoraEvento::searchEvent(ControladoraDados* database){
    Date a;
    Date b;
    City cid;
    State est;
    cout << "-- PESQUISAR EVENTOS --" << endl;
    cout << "Achar evento entre a data inicial: ";
    string firstdate;
    cin  >> firstdate;
    cout << "e a data final: ";
    string seconddate;
    cin >> seconddate;
    cout << "Cidade do evento: ";
    string cidade;
    cin.ignore();
    getline(cin,cidade);
    cout << "Estado: ";
    string estado;
    cin >> estado;
    try{
        a.setDate(firstdate);
        b.setDate(seconddate);
        cid.setCity(cidade);
        est.setState(estado);
    } catch(invalid_argument excecao){
        cout << "Argumento inválido encontrado" << endl;
        cout << "--------------------------" << endl;
        return false;
    }
    int year, initialyear, finalyear, month, initialmonth, finalmonth, day, initialday, finalday;
    string data;
    initialyear = stoi(firstdate.substr(7,2));
    finalyear = stoi(seconddate.substr(7,2));
    initialmonth = stoi(firstdate.substr(3,2));
    finalmonth = stoi(seconddate.substr(3,2));
    initialday = stoi(firstdate.substr(0,2));
    finalday = stoi(seconddate.substr(0,2));
    Event y;
    string name;
    string previus = "LLLLLLLLLLLLL";
    int i = 1;
    for(Presentation x: database->getPresentationList()){
        data = x.getPresentationDate().getDate();
        y = x.getMain();
        EventName en = y.getNameofEvent();
        string city = y.getEventCity().getCity();
        string state = y.getEventState().getState();
        name = en.getEventName();
        if(name == previus){
            continue;
        }
        day = stoi(data.substr(0,2));
        month = stoi(data.substr(3,2));
        year = stoi(data.substr(7,2));
        if((year >= initialyear) && (year <= finalyear)){
            if((month >= initialmonth) && (month <= finalmonth)){
                if((day >= initialday) && (day <= finalday)){
                    if(city == cidade){
                        if(estado == state){
                            cout << i << ". " << "Nome: " << name << endl;
                            for(Presentation k : database->getPresentationList()){
                                string eventname;
                                string classevent;
                                switch(k.getMain().getClassofEvent().getEventClass()){
                                    case 1: classevent = "TEATRO";
                                            break;
                                    case 2: classevent = "ESPORTE";
                                            break;
                                    case 3: classevent = "SHOW NACIONAL";
                                            break;
                                    case 4: classevent = "SHOW INTERNACIONAL";
                                            break;
                                }
                                eventname = k.getMain().getNameofEvent().getEventName();
                                if(eventname == name){
                                    cout << "Código "<< k.getCodeofPresentation().getPresentationCode() << " - " << k.getPresentationDate().getDate() << " - "
                                    << k.getPresentationSchedule().getSchedule() << " - " << k.getPresentationPrice().getPrice() << " - "
                                    << k.getPresentationAvailability().getAvailability() << " - " << classevent << " - Faixa: " << k.getMain().getEventAgeRange().getAge()
                                    << " - " << k.getPresentationAvailability().getAvailability() <<" Ingressos Disponíveis" << endl;
                                }
                            }
                            previus = name;
                            i++;
                        }
                    }
                }
            }
        }
    }
    if(i == 1){
        cout << "Nenhum evento encontrado." << endl;
        cout << "--------------------------" << endl;
        return false;
    }
    return true;
}

bool ControladoraEvento::deleteEvent(ControladoraDados* database, ControladoraUsuario* usercontrol){
    int i = 1;
    vector<Event> events_list;
    cout << "-- DESCADASTRAMENTO DE EVENTO --" << endl;
    cout << "Selecione um dos eventos:" << endl;
    for(Event x : database->getEventList()){
        User dono = x.getOwner();
        Cpf cpf_dono = dono.getUserCpf();
        User logado = usercontrol->getUser();
        Cpf cpf_logado = logado.getUserCpf();
        if(cpf_dono.getCpf() == cpf_logado.getCpf()){
            EventName ev = x.getNameofEvent();
            string nome = ev.getEventName();
            cout << '(' <<  i << ')' << ' ' << nome << ':' << /*database->getIngressosVendidos(database);*/endl;
            i++;
            events_list.push_back(x);
        }
    }
    if(i == 1){
        cout << "Você não criou nenhum evento." << endl;
        cout << "--------------------------" << endl;
        return false;
    }
    int entrada;
    cin >> entrada;
    if(entrada < i && entrada > 0){
        database->deletaEvento(events_list[entrada-1]);
        cout << "--------------------------" << endl;
        return true;
    }
    else{
        cout << "Opção inválida" << endl;
        cout << "--------------------------" << endl;
        return false;
    }
}