#ifndef TESTS_H_INCLUDED
#define TESTS_H_INCLUDED

#include "domains.h"
#include "entities.h"
#include <string>
using namespace std;

void DomainTests();
void EntitiesTests();

class TUCpf{
    private:
        const static string VALID_VALUE;   
        const static string INVALID_VALUE; 

        Cpf *cpftest;
        int state;

        void setUp();
        void tearDown();
        void testSucessScenario();
        void testFailureScenario();

    public:
        const static int SUCCESS =  0;
        const static int FAILURE  = -1;

        int run();
};

class TUPassword{
    private:
        const static string VALID_VALUE;   
        const static string INVALID_VALUE; 

        Password *passwordtest;
        int state;

        void setUp();
        void tearDown();
        void testSucessScenario();
        void testFailureScenario();

    public:
        const static int SUCCESS =  0;
        const static int FAILURE  = -1;

        int run();
};

class TUEventCode{
    private:
        const static string VALID_VALUE;   
        const static string INVALID_VALUE; 

        EventCode *eventcodetest;
        int state;

        void setUp();
        void tearDown();
        void testSucessScenario();
        void testFailureScenario();

    public:
        const static int SUCCESS =  0;
        const static int FAILURE  = -1;

        int run();
};

class TUEventName{
    private:
        const static string VALID_VALUE;   
        const static string INVALID_VALUE; 

        EventName *eventnametest;
        int state;

        void setUp();
        void tearDown();
        void testSucessScenario();
        void testFailureScenario();

    public:
        const static int SUCCESS =  0;
        const static int FAILURE  = -1;

        int run();
};

class TUCity{
    private:
        const static string VALID_VALUE;   
        const static string INVALID_VALUE; 

        City *citytest;
        int state;

        void setUp();
        void tearDown();
        void testSucessScenario();
        void testFailureScenario();

    public:
        const static int SUCCESS =  0;
        const static int FAILURE  = -1;

        int run();
};

class TUState{
    private:
        const static string VALID_VALUE;   
        const static string INVALID_VALUE; 

        State *statetest;
        int state;

        void setUp();
        void tearDown();
        void testSucessScenario();
        void testFailureScenario();

    public:
        const static int SUCCESS =  0;
        const static int FAILURE  = -1;

        int run();
};

class TUEventClass{
    private:
        const static int VALID_VALUE;   
        const static int INVALID_VALUE; 

        EventClass *eventclasstest;
        int state;

        void setUp();
        void tearDown();
        void testSucessScenario();
        void testFailureScenario();

    public:
        const static int SUCCESS =  0;
        const static int FAILURE  = -1;

        int run();
};

class TUAgeRange{
    private:
        const static string VALID_VALUE;   
        const static string INVALID_VALUE; 

        AgeRange *agerangetest;
        int state;

        void setUp();
        void tearDown();
        void testSucessScenario();
        void testFailureScenario();

    public:
        const static int SUCCESS =  0;
        const static int FAILURE  = -1;

        int run();
};

class TUPresentationCode{
    private:
        const static string VALID_VALUE;   
        const static string INVALID_VALUE; 

        PresentationCode *presentationcodetest;
        int state;

        void setUp();
        void tearDown();
        void testSucessScenario();
        void testFailureScenario();

    public:
        const static int SUCCESS =  0;
        const static int FAILURE  = -1;

        int run();
};

class TUDate{
    private:
        const static string VALID_VALUE;   
        const static string INVALID_VALUE; 

        Date *datetest;
        int state;

        void setUp();
        void tearDown();
        void testSucessScenario();
        void testFailureScenario();

    public:
        const static int SUCCESS =  0;
        const static int FAILURE  = -1;

        int run();
};

class TUSchedule{
    private:
        const static string VALID_VALUE;   
        const static string INVALID_VALUE; 

        Schedule *scheduletest;
        int state;

        void setUp();
        void tearDown();
        void testSucessScenario();
        void testFailureScenario();

    public:
        const static int SUCCESS =  0;
        const static int FAILURE  = -1;

        int run();
};

class TUPrice{
    private:
        const static string VALID_VALUE;   
        const static string INVALID_VALUE; 

        Price *pricetest;
        int state;

        void setUp();
        void tearDown();
        void testSucessScenario();
        void testFailureScenario();

    public:
        const static int SUCCESS =  0;
        const static int FAILURE  = -1;

        int run();
};

class TURoom{
    private:
        const static int VALID_VALUE;   
        const static int INVALID_VALUE; 

        Room *roomtest;
        int state;

        void setUp();
        void tearDown();
        void testSucessScenario();
        void testFailureScenario();

    public:
        const static int SUCCESS =  0;
        const static int FAILURE  = -1;

        int run();
};

class TUAvailable{
    private:
        const static int VALID_VALUE;   
        const static int INVALID_VALUE; 

        Availability *availabletest;
        int state;

        void setUp();
        void tearDown();
        void testSucessScenario();
        void testFailureScenario();

    public:
        const static int SUCCESS =  0;
        const static int FAILURE  = -1;

        int run();
};

class TUTicketCode{
    private:
        const static string VALID_VALUE;   
        const static string INVALID_VALUE; 

        TicketCode *ticketcodetest;
        int state;

        void setUp();
        void tearDown();
        void testSucessScenario();
        void testFailureScenario();

    public:
        const static int SUCCESS =  0;
        const static int FAILURE  = -1;

        int run();
};

class TUCreditCardNumber{
    private:
        const static string VALID_VALUE;   
        const static string INVALID_VALUE; 

        NumberCreditCard *creditcardnumbertest;
        int state;

        void setUp();
        void tearDown();
        void testSucessScenario();
        void testFailureScenario();

    public:
        const static int SUCCESS =  0;
        const static int FAILURE  = -1;

        int run();
};

class TUSecurityCode{
    private:
        const static int VALID_VALUE;   
        const static int INVALID_VALUE; 

        SecurityCode *securitycodetest;
        int state;

        void setUp();
        void tearDown();
        void testSucessScenario();
        void testFailureScenario();

    public:
        const static int SUCCESS =  0;
        const static int FAILURE  = -1;

        int run();
};

class TUValidityDate{
    private:
        const static string VALID_VALUE;   
        const static string INVALID_VALUE; 

        ValidityDate *validitydatetest;
        int state;

        void setUp();
        void tearDown();
        void testSucessScenario();
        void testFailureScenario();

    public:
        const static int SUCCESS =  0;
        const static int FAILURE  = -1;

        int run();
};

// Entities
class TUUser{
    private:
        const static string VALID_VALUE;   
        const static string INVALID_VALUE; 

        User *usertest;
        Cpf cpfvalid;
        Cpf cpfinvalid;
        int state;

        void setUp();
        void tearDown();
        void testSucessScenario();
        void testFailureScenario();

    public:
        const static int SUCCESS =  0;
        const static int FAILURE  = -1;

        int run();
};

class TUEvent{
    private:
        const static string VALID_VALUE;   
        const static string INVALID_VALUE; 

        Event *eventtest;
        EventName evvalid;
        EventName evinvalid;
        int state;

        void setUp();
        void tearDown();
        void testSucessScenario();
        void testFailureScenario();

    public:
        const static int SUCCESS =  0;
        const static int FAILURE  = -1;

        int run();
};

class TUPresentation{
    private:
        const static string VALID_VALUE;   
        const static string INVALID_VALUE; 

        Presentation *presentationtest;
        Schedule scvalid;
        Schedule scinvalid;
        int state;

        void setUp();
        void tearDown();
        void testSucessScenario();
        void testFailureScenario();

    public:
        const static int SUCCESS =  0;
        const static int FAILURE  = -1;

        int run();
};

class TUTicket{
    private:
        const static string VALID_VALUE;   
        const static string INVALID_VALUE; 

        Ticket *tickettest;
        TicketCode tcvalid;
        TicketCode tcinvalid;
        int state;

        void setUp();
        void tearDown();
        void testSucessScenario();
        void testFailureScenario();

    public:
        const static int SUCCESS =  0;
        const static int FAILURE  = -1;

        int run();
};

class TUCreditCard{
    private:
        const static string VALID_VALUE;   
        const static string INVALID_VALUE; 

        CreditCard *cctest;
        NumberCreditCard ccvalid;
        NumberCreditCard ccinvalid;
        int state;

        void setUp();
        void tearDown();
        void testSucessScenario();
        void testFailureScenario();

    public:
        const static int SUCCESS =  0;
        const static int FAILURE  = -1;

        int run();
};
#endif // TESTES_H_INCLUDED