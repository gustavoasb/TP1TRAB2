#include <iostream>
#include "domains.h"
#include "entities.h"
#include "tests.h"
#include "ControladoraDados.h"
#include "ControladoraUsuario.h"
#include "ControladoraEventos.h"
#include "UI.h"
using namespace std;

int main(void){
    ControladoraDados database;
    ControladoraUsuario usercontrol;
    ControladoraEvento eventcontrol;
    database.readDataFiles();
    UITelaInicial start;
    start.executar(&database,&usercontrol);
    return 0;
}

