#ifndef UI_H_INCLUDED
#define UI_H_INCLUDED
#include "ControladoraDados.h"
#include "ControladoraUsuario.h"
#include "ControladoraEventos.h"
#include "ControladoraIngresso.h"

class UITelaInicial{
    private:
    public:
    void executar(ControladoraDados *database, ControladoraUsuario *usercontrol);
};

class UITelaLogin{
    private:
    public:
    void executar(ControladoraDados *database, ControladoraUsuario *usercontrol);
};

class UITelaCadastro{
    private:
    public:
    void executar(ControladoraDados *database, ControladoraUsuario *usercontrol);
};

class UITelaDescadastrar{
    private:
    public:
    void executar(ControladoraDados *database, ControladoraUsuario *usercontrol);
};

class UITelaLogado{
    private:
    public:
    void executar(ControladoraDados *database, ControladoraUsuario *usercontrol);
};

class UITelaComprarIngresso{
    private:
    public:
    void executar(ControladoraDados *database, ControladoraUsuario *usercontrol);
};

class UITelaPesquisarEventos{
    private:
    public:
    void executar(ControladoraDados *database, ControladoraUsuario *usercontrol);
};

class UITelaCriarEvento{
    private:
    public:
    void executar(ControladoraDados *database, ControladoraUsuario *usercontrol);
};

class UITelaEditarEvento{
    private:
    public:
    void executar(ControladoraDados *database, ControladoraUsuario *usercontrol);
};

class UITelaRemoverEvento{
    private:
    public:
    void executar(ControladoraDados *database, ControladoraUsuario *usercontrol);
};

class UITelaConsultarEventos{
    private:
    public:
    void executar(ControladoraDados *database, ControladoraUsuario *usercontrol);
};

class UITelaDeletarConta{
    private:
    public:
    void executar(ControladoraDados *database, ControladoraUsuario *usercontrol);
};

#endif