#ifndef USER_H_INCLUDED
#define USER_H_INCLUDED

#include "entities.h"

class ControladoraUsuario{
    private:
        User logado;
        int index; /* index of the logged user in the lists */
        int state; /* 1 for looged, 0 for unlogged */
    public:
        ControladoraUsuario(){
            this->state = 0;
        }
        bool createUser(ControladoraDados *database);
        void deleteUser(ControladoraDados *database);
        bool loginUser(ControladoraDados *database);
        void deslogarUser(ControladoraDados *database);
        User getUser();
        int getState();
};

#endif