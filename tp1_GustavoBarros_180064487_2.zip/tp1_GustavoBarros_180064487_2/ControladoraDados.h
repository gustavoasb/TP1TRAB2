#ifndef DATABASE_H_INCLUDED
#define DATABASE_H_INCLUDED

#include <list>
#include "entities.h"

class ControladoraDados{
    private:
        list<User> userList;
        list<CreditCard> ccList;
        list<Event> eventList;
        list<Presentation> presentationList;
        list<Ticket> ticketList;
        int n_tickets;
    public:
        ControladoraDados(){
            this->n_tickets = 0;
        }
        list<User> getUserList();
        list<CreditCard> getCCList();
        list<Event> getEventList();
        list<Presentation> getPresentationList();
        list<Ticket> getTicketList();
        void readDataFiles();
        void armazenaUser(User x);
        void armazenaCC(CreditCard cc);
        void armazenaEvento(Event ev);
        void armazenaPresent(Presentation pr);
        void armazenaTicket(Ticket ticket);
        void deletaUserData(int index);
        void deletaCCData(int index);
        void deletaEvento(Event ev);
        void listaUser();
        void listaCC();
        void listaEvento();
        void editaDadosEvento(Event x);
        void acrescentaTicket(int n);
        int getNTickets();
        bool diminuiDisponibilidade(int n, Presentation p);
};

#endif