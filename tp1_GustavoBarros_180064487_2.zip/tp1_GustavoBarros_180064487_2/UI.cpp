#include "UI.h"
#include "ControladoraUsuario.h"
#include "ControladoraEventos.h"
#include "ControladoraDados.h"
#include "ControladoraIngresso.h"
#include <iostream>
#include <string>
using namespace std;

void UITelaInicial::executar(ControladoraDados *database, ControladoraUsuario *usercontrol){
    cout << "-- Bem vindo ao sistema de compra de ingressos --" << endl;
    cout << "Selecione uma das opções abaixo para continuar:" << endl;
    cout << "(1) Logar" << endl;
    cout << "(2) Criar novo usuário" << endl;
    cout << "(3) Fechar programa" << endl;
    cout << "--------------------------" << endl;
    int entrada;
    cin >> entrada;
    switch(entrada){
        case 1: UITelaLogin* comando;
                comando = new UITelaLogin();
                comando->executar(database, usercontrol);
                delete comando;
                break;
        case 2: UITelaCadastro* comando2;
                comando2 = new UITelaCadastro();
                comando2->executar(database, usercontrol);
                delete comando2;
                break;
        case 3: exit(0);
                break;
        default: cout << "Opção inválida" << endl;
                 this->executar(database, usercontrol);
                 break;
    }
};

void UITelaCadastro::executar(ControladoraDados *database, ControladoraUsuario *usercontrol){
    bool result = usercontrol->createUser(database);
    if(result){
        UITelaLogado *comando;
        comando = new UITelaLogado();
        comando->executar(database, usercontrol);
        delete comando;
    }
    else{
        cout << "DESEJA TENTAR SE REGISTRAR NOVAMENTE? y/n" << endl;
        char entrada;
        cin >> entrada;
        switch(entrada){
            case 'y': this->executar(database, usercontrol);
                    break;
            case 'n': UITelaInicial* comando;
                    comando->executar(database,usercontrol);
                    delete comando;
                    break;
            default: this->executar(database,usercontrol);
                    break;
        }
    }
};

void UITelaLogado::executar(ControladoraDados *database, ControladoraUsuario *usercontrol){
    User logado = usercontrol->getUser();
    Cpf cpf = logado.getUserCpf();
    cout << "-- Bem vindo, usuário " << cpf.getCpf() << " --" << endl;
    cout << "(1) Comprar ingresso" << endl;
    cout << "(2) Pesquisar eventos" << endl;
    cout << "(3) Criar evento" << endl;
    cout << "(4) Editar evento" << endl;
    cout << "(5) Remover evento" << endl;
    cout << "(6) Consultar eventos criados" << endl;
    cout << "(7) Deletar conta" << endl;
    cout << "(8) Deslogar" << endl;
    cout << "--------------------------" << endl;
    int entrada;
    cin >> entrada;
    switch(entrada){
        case 1: UITelaComprarIngresso* comando;
                comando = new UITelaComprarIngresso();
                comando->executar(database, usercontrol);
                delete comando;
                break;
        case 2: UITelaPesquisarEventos* comando2;
                comando2 = new UITelaPesquisarEventos();
                comando2->executar(database, usercontrol);
                delete comando2;
                break;
        case 3: UITelaCriarEvento* comando3;
                comando3 = new UITelaCriarEvento();
                comando3->executar(database, usercontrol);
                delete comando3;
                break;
        case 4: UITelaEditarEvento* comando4;
                comando4 = new UITelaEditarEvento();
                comando4->executar(database, usercontrol);
                delete comando4;
                break;
        case 5: UITelaRemoverEvento* comando5;
                comando5 = new UITelaRemoverEvento();
                comando5->executar(database, usercontrol);
                delete comando5;
                break;
        case 6: UITelaConsultarEventos* comando6;
                comando6 = new UITelaConsultarEventos();
                comando6->executar(database, usercontrol);
                delete comando6;
                break;
        case 7: UITelaDeletarConta* comando7;
                comando7 = new UITelaDeletarConta();
                comando7->executar(database, usercontrol);
                delete comando7;
                break;
        case 8: UITelaInicial* comando8;
                comando8 = new UITelaInicial();
                comando8->executar(database, usercontrol);
                usercontrol->deslogarUser(database);
                delete comando8;
                break;
        default: cout << "Opção inválida" << endl;
                 this->executar(database, usercontrol);
                 break;
    }
};

void UITelaLogin::executar(ControladoraDados *database, ControladoraUsuario *usercontrol){
    bool result = usercontrol->loginUser(database);
    if(result){
        UITelaLogado *comando;
        comando = new UITelaLogado();
        comando->executar(database, usercontrol);
        delete comando;
    }
    else{
        cout << "DESEJA TENTAR LOGAR NOVAMENTE? y/n" << endl;
        char entrada;
        cin >> entrada;
        switch(entrada){
            case 'y': this->executar(database, usercontrol);
                    break;
            case 'n': UITelaInicial* comando;
                    comando->executar(database,usercontrol);
                    delete comando;
                    break;
            default: cout << "Opção Inválida" << endl;
                    this->executar(database,usercontrol);
        }
    }
}

void UITelaDeletarConta::executar(ControladoraDados *database, ControladoraUsuario *usercontrol){
    cout << "DESEJA REALMENTE DELETAR SUA CONTA? y/n" << endl;
    char entrada;
    cin >> entrada;
    switch(entrada){
        case 'y': usercontrol->deleteUser(database);
                UITelaInicial* comando2;
                comando2->executar(database,usercontrol);
                delete comando2;
                break;
        case 'n': UITelaLogado *comando;
                comando = new UITelaLogado();
                comando->executar(database, usercontrol);
                delete comando;
                break;
        default: cout << "Opção inválida." << endl;
                this->executar(database,usercontrol);
    }
}

void UITelaCriarEvento::executar(ControladoraDados *database, ControladoraUsuario *usercontrol){
    ControladoraEvento eventcontrol;
    bool result = eventcontrol.createEvent(database,usercontrol);
    if(result){
        UITelaLogado* comando;
        comando = new UITelaLogado();
        comando->executar(database,usercontrol);
        delete comando;
    }
    else{
        cout << "DESEJA TENTAR CRIAR O EVENTO NOVAMENTE? y/n" << endl;
        char entrada;
        cin >> entrada;
        switch(entrada){
            case 'y': this->executar(database, usercontrol);
                    break;
            case 'n': UITelaLogado* comando;
                    comando = new UITelaLogado();
                    comando->executar(database,usercontrol);
                    delete comando;
                    break;
            default: cout << "Opção inválida" << endl;
                    this->executar(database, usercontrol);
                    break;
        }
    }
}

void UITelaConsultarEventos::executar(ControladoraDados *database, ControladoraUsuario *usercontrol){
    ControladoraEvento eventcontrol;
    eventcontrol.consultaEvent(database,usercontrol);
    cout << "Digite algo para retornar" << endl;
    string input;
    cin >> input;
    if(input != "seila,vcnuncavaidigitarisso"){
        UITelaLogado* comando;
        comando = new UITelaLogado();
        comando->executar(database,usercontrol);
        delete comando;
    }
}

void UITelaPesquisarEventos::executar(ControladoraDados *database, ControladoraUsuario *usercontrol){
    ControladoraEvento eventcontrol;
    bool result = eventcontrol.searchEvent(database);
    if(result){
        cout << "Deseja ser redirecionado para a compra de ingressos? y/n " << endl;
        char input;
        cin >> input;
        switch(input){
            case 'y': UITelaComprarIngresso* comando3;
                    comando3 = new UITelaComprarIngresso();
                    comando3->executar(database,usercontrol);
                    delete comando3;
                    break;
            case 'n': UITelaLogado* comando;
                    comando = new UITelaLogado();
                    comando->executar(database,usercontrol);
                    delete comando;
                    break;
            default: UITelaLogado* comando2;
                    comando2 = new UITelaLogado();
                    comando2->executar(database,usercontrol);
                    delete comando2;
                    break;
        }
    }
    else{
        cout << "DESEJA TENTAR PESQUISAR UM EVENTO NOVAMENTE? y/n" << endl;
        char input;
        cin >> input;
        switch(input){
            case 'y': this->executar(database,usercontrol);
                    break;
            case 'n': UITelaLogado* comando;
                    comando = new UITelaLogado();
                    comando->executar(database,usercontrol);
                    delete comando;
                    break;
            default: cout << "Opção inválida, voltando para o menu inicial..." << endl;
                    UITelaLogado* comando2;
                    comando2 = new UITelaLogado();
                    comando2->executar(database,usercontrol);
                    delete comando2;
                    break;
        }
    }
}

void UITelaComprarIngresso::executar(ControladoraDados *database, ControladoraUsuario *usercontrol){
    ControladoraIngresso ticketcontrol;
    bool result = ticketcontrol.compraIngresso(database,usercontrol);
    if(result){
        UITelaLogado* comando;
        comando = new UITelaLogado();
        comando->executar(database,usercontrol);
        delete comando;
    }
    else{
        cout << "Algo deu errado, tente comprar novamente" << endl;
        UITelaLogado* comando2;
        comando2 = new UITelaLogado();
        comando2->executar(database,usercontrol);
        delete comando2;
    }
}

void UITelaEditarEvento::executar(ControladoraDados *database, ControladoraUsuario *usercontrol){
    ControladoraEvento eventcontrol;
    bool result = eventcontrol.editEvent(database,usercontrol);
    if(result){
        UITelaLogado* comando;
        comando = new UITelaLogado();
        comando->executar(database,usercontrol);
        delete comando;
    }
    else{
        cout << "DESEJA TENTAR EDITAR UM EVENTO NOVAMENTE? y/n" << endl;
        char input;
        cin >> input;
        switch(input){
            case 'y': this->executar(database,usercontrol);
                    break;
            case 'n': UITelaLogado* comando;
                    comando = new UITelaLogado();
                    comando->executar(database,usercontrol);
                    delete comando;
                    break;
            default: cout << "Opção inválida, voltando para o menu inicial..." << endl;
                    UITelaLogado* comando2;
                    comando2 = new UITelaLogado();
                    comando2->executar(database,usercontrol);
                    delete comando2;
                    break;
        }
    }
}

void UITelaRemoverEvento::executar(ControladoraDados *database, ControladoraUsuario *usercontrol){
    ControladoraEvento eventcontrol;
    bool result = eventcontrol.deleteEvent(database,usercontrol);
    if(result){
        UITelaLogado* comando;
        comando = new UITelaLogado();
        comando->executar(database,usercontrol);
        delete comando;
    }
    else{
        cout << "DESEJA TENTAR REMOVER NOVAMENTE? y/n" << endl;
        char input;
        cin >> input;
        switch(input){
            case 'y': this->executar(database,usercontrol);
                    break;
            case 'n': UITelaLogado* comando3;
                    comando3 = new UITelaLogado();
                    comando3->executar(database,usercontrol);
                    delete comando3;
                    break;
            default:
                    cout << "Opção inválida, voltando para o menu inicial..." << endl;
                    UITelaLogado* comando2;
                    comando2 = new UITelaLogado();
                    comando2->executar(database,usercontrol);
                    delete comando2;
                    break;
        }
    }
}
