#ifndef ENTITIES_H_INCLUDED
#define ENTITIES_H_INCLUDED

#include "domains.h"
#include <string>
#include <list>
using namespace std;

// Declaração de classe.

class User{
private:
    Cpf usercpf;
    Password userpassword;
    int n_eventos = 0;
public:
    void setUserCpf(const Cpf &usercpf);
    Cpf getUserCpf() const;

    void setUserPassword(const Password &password);
    Password getUserPassword() const;

    void acrescentaNEventos(int n);
    int getNEventos();
};

class Event{
private:
    User owner;
    int n_presentations = 0;
    EventCode code;
    EventName name;
    City city;
    State state;
    EventClass eclass;
    AgeRange agerange;
public:
    void setCodeofEvent(const EventCode &code);
    EventCode getCodeofEvent() const;

    void setNameofEvent(const EventName &name);
    EventName getNameofEvent() const;

    void setEventCity(const City &city);
    City getEventCity() const;

    void setEventState(const State &state);
    State getEventState() const;

    void setClassofEvent(const EventClass &eclass);
    EventClass getClassofEvent() const;

    void setEventAgeRange(const AgeRange &agerange);
    AgeRange getEventAgeRange() const;

    void setOwner(User x);
    User getOwner();

    void acrescentaNPresentations(int k);
    int getNPresentations();
};

class Presentation{
private:
    Event main;
    PresentationCode code;
    Date date;
    Schedule schedule;
    Price price;
    Room room;
    Availability available;
public:
    void setCodeofPresentation(const PresentationCode &code);
    PresentationCode getCodeofPresentation() const;

    void setPresentationDate(const Date &date);
    Date getPresentationDate() const;

    void setPresentationSchedule(const Schedule &schedule);
    Schedule getPresentationSchedule() const;
    
    void setPresentationPrice(const Price &price);
    Price getPresentationPrice() const;

    void setPresentationRoom(const Room &room);
    Room getPresentationRoom() const;
    
    void setPresentationAvailability(const Availability &available);
    Availability getPresentationAvailability() const;

    void setMain(Event x);
    Event getMain();
};

class Ticket{
private:
    Presentation x;
    TicketCode code;
    Cpf cpf;
public:
    void setCodeofTicket(const TicketCode &code);
    TicketCode getCodeofTicket() const;

    Presentation getPresentation();
    void setPresentation(Presentation x);

    void setCpf(Cpf cpf);
    Cpf getCpf();
};

class CreditCard{
private:
    NumberCreditCard number;
    SecurityCode code;
    ValidityDate date;
public:
    void setCCNumber(const NumberCreditCard &number);
    NumberCreditCard getCCNumber() const;

    void setCCSecurityCode(const SecurityCode &code);
    SecurityCode getCCSecurityCode() const;

    void setCCValidityCode(const ValidityDate &date);
    ValidityDate getCCValidityCode() const;
};

#endif // ENTITIES_H_INCLUDED