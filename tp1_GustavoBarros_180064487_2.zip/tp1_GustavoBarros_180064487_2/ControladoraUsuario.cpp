
#include <iostream>
#include <string>
#include <stdexcept>
#include <list>
#include "ControladoraDados.h"
#include "domains.h"
#include "entities.h"
#include "ControladoraUsuario.h"
using namespace std;

bool ControladoraUsuario::createUser(ControladoraDados *database){
    User x;
    CreditCard c;
    cout << "-- CRIAÇÃO DE USUÁRIO --\n";
    try{
        string cpf;
        cout << "Insira seu CPF: ";
        cin >> cpf;
        Cpf a;
        a.setCpf(cpf);
        x.setUserCpf(a);
    }
    catch(invalid_argument excecao){
        cout << "Argumento Inválido Encontrado, Encerrando Cadastramento..." << endl;
        cout << "--------------------------" << endl;
        return false;
    }
    try{
        string senha;
        cout << "Insira uma senha: ";
        cin >> senha;
        Password a;
        a.setPassword(senha);
        x.setUserPassword(a);
    }
    catch(invalid_argument excecao){
        cout << "Argumento Inválido Encontrado, Encerrando Cadastramento...\n";
        cout << "--------------------------" << endl;
        return false;
    }
    try{
        string numerocc;
        string validade;
        int cvc;
        cout << "Insira o número do cartão de crédito: ";
        cin >> numerocc;
        cout << "Insira a data de validade: ";
        cin >> validade;
        cout << "Insira o código de seguração: ";
        cin >> cvc;
        NumberCreditCard n;
        ValidityDate date;
        SecurityCode code;
        n.setNumberCreditCard(numerocc);
        date.setValidityDate(validade);
        code.setSecurityCode(cvc);
        c.setCCNumber(n);
        c.setCCSecurityCode(code);
        c.setCCValidityCode(date);
    }
    catch(invalid_argument excecao){
        cout << "Argumento Inválido Encontrado, Encerrando Cadastramento...\n";
        cout << "--------------------------" << endl;
        return false;
    }
    database->armazenaCC(c);
    database->armazenaUser(x);
    cout << "Usuário criado com sucesso.\n";
    cout << "--------------------------" << endl;
    this->logado = x;
    this->state = 1;
    return true;
}

bool ControladoraUsuario::loginUser(ControladoraDados *database){
    cout << "-- AUTENTICAÇÃO DE USUÁRIO --\n";
    string senha;
    string cpf;
    cout << "CPF: ";
    cin >> cpf;
    cout << "Senha: ";
    cin >> senha;
    int i = 0;
    for(User x: database->getUserList()){
        Cpf y = x.getUserCpf();
        Password k = x.getUserPassword();
        if(y.getCpf() == cpf){
            if(k.getPassword() == senha){
                cout << "Usuário encontrado com successo, Logado como " << cpf << endl;
                cout << "--------------------------" << endl;
                this->state = 1;
                this->index = i;
                this->logado = x;
                return true;
            }
            else{
                cout << "Dados de autenticação incorretos." << endl;
                cout << "--------------------------" << endl;
                return false;
            }
        }
        i++;
    }
    cout << "CPF não encontrado." << endl;
    cout << "--------------------------" << endl;
    return false;
}

void ControladoraUsuario::deleteUser(ControladoraDados *database){
    if(this->state == 1){
        database->deletaUserData(this->index);
        database->deletaCCData(this->index);
    }
    else{
        cout << "É necessário logar para decadastrar o usuário." << endl;
    }
}

User ControladoraUsuario::getUser(){
    return this->logado;
}

void ControladoraUsuario::deslogarUser(ControladoraDados *database){
    User c; //NULL
    this->logado = c;
}

int ControladoraUsuario::getState(){
    return this->state;
}
