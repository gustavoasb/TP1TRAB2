#ifndef EVENT_H_INCLUDED
#define EVENT_H_INCLUDED

#include "ControladoraDados.h"
#include "ControladoraUsuario.h"

class ControladoraEvento{
    private:
    public:
        bool createEvent(ControladoraDados *database,ControladoraUsuario *usercontrol);
        bool deleteEvent(ControladoraDados* database, ControladoraUsuario* usercontrol);
        bool editEvent(ControladoraDados* database, ControladoraUsuario* usercontrol);
        void consultaEvent(ControladoraDados* database, ControladoraUsuario* usercontrol);
        bool searchEvent(ControladoraDados* database);
};

#endif