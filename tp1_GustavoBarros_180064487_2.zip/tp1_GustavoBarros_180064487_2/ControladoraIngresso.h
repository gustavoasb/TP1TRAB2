#ifndef TICKET_H_INCLUDED
#define TICKET_H_INCLUDED

#include "ControladoraDados.h"
#include "ControladoraUsuario.h"
#include "entities.h"

class ControladoraIngresso{
    private:
    public:
        bool compraIngresso(ControladoraDados *database, ControladoraUsuario *usercontrol);
};

#endif